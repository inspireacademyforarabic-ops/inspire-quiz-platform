-- Arabic question bank: 7 units, 14 published quizzes (145 multiple-choice, 70 statement questions).
-- Statement questions put the statements in the question text. Fixed ids keep this safe to run once.

INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100001, 'mcq', 'من عرّف اللغة بأنها «أصوات يعبّر بها كل قوم عن أغراضهم»؟', '["ابن فارس", "ابن جني", "ابن خلدون", "الجاحظ"]', '[1]', 'التعريف المشهور للغة منسوب إلى ابن جني.', 'UGC NET Arabic', 'الوحدة ١ · اللغة العربية وأصلها والشعر من الجاهلية إلى العصر العباسي', 'easy');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100002, 'mcq', 'أول من استعمل مصطلح «السامية» في القرن الثامن عشر هو المستشرق:', '["نولدكه", "رينان", "شلوزر", "جرجي زيدان"]', '[2]', '«السامية» اسم اصطلاحي نشأ في القرن الثامن عشر واستعمله أول مرة المستشرق شلوزر.', 'UGC NET Arabic', 'الوحدة ١ · اللغة العربية وأصلها والشعر من الجاهلية إلى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100003, 'mcq', 'القائل: «ليست حمير بلغتنا ولا عربيتهم بعربيتنا» هو:', '["ابن سلام الجمحي", "الأصمعي", "الخليل بن أحمد", "أبو عمرو بن العلاء"]', '[3]', 'القول لأبي عمرو بن العلاء في اختلاف لغة اليمن عن لغة الشمال.', 'UGC NET Arabic', 'الوحدة ١ · اللغة العربية وأصلها والشعر من الجاهلية إلى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100004, 'mcq', 'تقع سوق عكاظ بين:', '["البصرة والكوفة", "عمان وعدن", "الطائف ونخلة", "مكة والمدينة"]', '[2]', 'عكاظ تقع بين الطائف ونخلة وعُرفت بملكة الأسواق.', 'UGC NET Arabic', 'الوحدة ١ · اللغة العربية وأصلها والشعر من الجاهلية إلى العصر العباسي', 'easy');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100005, 'mcq', 'مؤسس الدولة الغسانية هو:', '["النعمان بن المنذر", "عمرو بن عدي", "عمرو بن الهند", "جفنة بن عمرو بن مزيقياء"]', '[3]', 'نُسب إليه آل جفنة، وهم من الأزد اليمنية.', 'UGC NET Arabic', 'الوحدة ١ · اللغة العربية وأصلها والشعر من الجاهلية إلى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100006, 'mcq', 'عاصمة دولة المناذرة هي:', '["مأرب", "الحيرة", "صنعاء", "بصرى"]', '[1]', 'كانت الحيرة عاصمة المناذرة، وآخر ملوكهم النعمان بن المنذر.', 'UGC NET Arabic', 'الوحدة ١ · اللغة العربية وأصلها والشعر من الجاهلية إلى العصر العباسي', 'easy');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100007, 'mcq', 'دارت حرب البسوس بين قبيلتي:', '["بكر وتغلب", "عبس وذبيان", "الأوس والخزرج", "قريش وكنانة"]', '[0]', 'حرب البسوس (الضروس) دارت بين بكر وتغلب.', 'UGC NET Arabic', 'الوحدة ١ · اللغة العربية وأصلها والشعر من الجاهلية إلى العصر العباسي', 'easy');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100008, 'mcq', 'أول من قصّد القصيدة، كما ورد في الكتاب، هو:', '["عنترة بن شداد", "امرؤ القيس", "مهلهل بن ربيعة", "زهير بن أبي سلمى"]', '[2]', 'يُنسب إلى مهلهل بن ربيعة أنه أول من قصّد القصيدة.', 'UGC NET Arabic', 'الوحدة ١ · اللغة العربية وأصلها والشعر من الجاهلية إلى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100009, 'mcq', 'صاحب المعلقة التي مطلعها «هل غادر الشعراء من متردم» هو:', '["الحارث بن حلزة", "عنترة بن شداد", "طرفة بن العبد", "لبيد بن ربيعة"]', '[1]', 'مطلع معلقة عنترة العبسي، وقد قاد كتائب عبس في حرب داحس والغبراء.', 'UGC NET Arabic', 'الوحدة ١ · اللغة العربية وأصلها والشعر من الجاهلية إلى العصر العباسي', 'easy');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100010, 'mcq', 'معلقة زهير بن أبي سلمى ميمية من بحر:', '["الطويل", "البسيط", "الكامل", "الوافر"]', '[0]', 'معلقة زهير ميمية من بحر الطويل.', 'UGC NET Arabic', 'الوحدة ١ · اللغة العربية وأصلها والشعر من الجاهلية إلى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100011, 'mcq', 'قال أبو عمرو بن العلاء: «لو أبطأ الإسلام لأكلت بنو تغلب الناس»، يقصد بذلك:', '["عنترة بن شداد", "عمرو بن معد يكرب", "المهلهل", "عمرو بن كلثوم"]', '[3]', 'القول في عمرو بن كلثوم التغلبي صاحب المعلقة.', 'UGC NET Arabic', 'الوحدة ١ · اللغة العربية وأصلها والشعر من الجاهلية إلى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100012, 'mcq', 'سبب تلقيب ثابت بن جابر بـ«تأبّط شرًّا» أنه:', '["قتل أخاه في الحرب", "حمل الشر في صدره على قومه", "هجا القبائل جميعها", "كان يضع سيفه تحت إبطه عند الخروج للغزو"]', '[3]', 'من التعليلات المذكورة أنه كان يضع سيفه تحت إبطه كلما خرج للغزو.', 'UGC NET Arabic', 'الوحدة ١ · اللغة العربية وأصلها والشعر من الجاهلية إلى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100013, 'mcq', 'قال له النبي ﷺ: «اهجُهم ومعك روح القدس»، والمقصود:', '["كعب بن مالك", "عبد الله بن رواحة", "كعب بن زهير", "حسان بن ثابت"]', '[3]', 'حسان بن ثابت شاعر الرسول ﷺ.', 'UGC NET Arabic', 'الوحدة ١ · اللغة العربية وأصلها والشعر من الجاهلية إلى العصر العباسي', 'easy');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100014, 'mcq', 'القصيدة التي افتتحها كعب بن زهير بذكر حبيبته سعاد هي:', '["بانت سعاد", "سقط الزند", "لامية العرب", "قفا نبك"]', '[0]', '«بانت سعاد» قالها كعب في مدح النبي ﷺ، وهي المعروفة بالبردة.', 'UGC NET Arabic', 'الوحدة ١ · اللغة العربية وأصلها والشعر من الجاهلية إلى العصر العباسي', 'easy');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100015, 'mcq', 'اسم الحطيئة الحقيقي هو:', '["عمرو بن أوس", "جرول بن أوس", "ثابت بن أوس", "حبيب بن أوس"]', '[1]', 'الحطيئة هو جرول بن أوس العبسي.', 'UGC NET Arabic', 'الوحدة ١ · اللغة العربية وأصلها والشعر من الجاهلية إلى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100016, 'mcq', 'رائد الشعر الغزلي والحب العذري في العصر الأموي هو:', '["عمر بن أبي ربيعة", "الفرزدق", "الأخطل", "جميل بن معمر"]', '[3]', 'جميل بثينة رائد الحب العذري.', 'UGC NET Arabic', 'الوحدة ١ · اللغة العربية وأصلها والشعر من الجاهلية إلى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100017, 'mcq', 'اللقب الذي اشتهر به أبو نواس هو:', '["شاعر الفلاسفة", "شاعر الحكمة", "شاعر الخمر", "شاعر النيل"]', '[2]', 'اشتُهر بكثرة وصف الخمر في شعره حتى لُقّب بشاعر الخمر.', 'UGC NET Arabic', 'الوحدة ١ · اللغة العربية وأصلها والشعر من الجاهلية إلى العصر العباسي', 'easy');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100018, 'mcq', 'قال ابن المعتز: «ليس للعربية سينية مثلها»، يقصد سينية:', '["أبي تمام", "البحتري", "ابن الرومي", "المتنبي"]', '[1]', 'سينية البحتري في وصف إيوان كسرى.', 'UGC NET Arabic', 'الوحدة ١ · اللغة العربية وأصلها والشعر من الجاهلية إلى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100019, 'mcq', 'الشاعر الذي يوصف بأنه «الشاعر الذي قتله شعره» هو:', '["أبو تمام", "المتنبي", "ابن الرومي", "بشار بن برد"]', '[1]', 'قُتل المتنبي بسبب بيت من شعره ذكّره به غلامه.', 'UGC NET Arabic', 'الوحدة ١ · اللغة العربية وأصلها والشعر من الجاهلية إلى العصر العباسي', 'easy');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100020, 'mcq', '«معجز أحمد» شرح لديوان:', '["المتنبي", "البحتري", "أبي تمام", "أبي نواس"]', '[0]', 'شرح أبو العلاء المعري ديوان المتنبي في «معجز أحمد».', 'UGC NET Arabic', 'الوحدة ١ · اللغة العربية وأصلها والشعر من الجاهلية إلى العصر العباسي', 'medium');
INSERT OR IGNORE INTO quizzes (id, title, description, instructions, subject, topic, difficulty, status, mode, duration_minutes, attempt_limit, pass_mark, marks_per_question, negative_marks, shuffle_questions, shuffle_options, show_answers, access_type, published_at) VALUES (1001, 'الوحدة ١ — اختيار من متعدد', 'اللغة العربية وأصلها والشعر من الجاهلية إلى العصر العباسي', 'اقرأ كل سؤال بعناية ثم اختر إجابة واحدة صحيحة. لكل سؤال درجتان ولا خصم على الإجابة الخاطئة.', 'UGC NET Arabic', 'اللغة العربية وأصلها والشعر من الجاهلية إلى العصر العباسي', 'medium', 'published', 'both', 20, 0, 40, 2, 0, 0, 0, 1, 'free', datetime('now'));
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1001, 100001, 0);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1001, 100002, 1);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1001, 100003, 2);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1001, 100004, 3);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1001, 100005, 4);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1001, 100006, 5);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1001, 100007, 6);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1001, 100008, 7);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1001, 100009, 8);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1001, 100010, 9);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1001, 100011, 10);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1001, 100012, 11);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1001, 100013, 12);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1001, 100014, 13);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1001, 100015, 14);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1001, 100016, 15);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1001, 100017, 16);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1001, 100018, 17);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1001, 100019, 18);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1001, 100020, 19);

INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100021, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - عرّف ابن جني اللغة بأنها أصوات يعبّر بها كل قوم عن أغراضهم
2 - استعمل مصطلح «السامية» أول مرة المستشرق شلوزر
3 - عاصمة دولة المناذرة هي بصرى الشام', '["العبارتان 2 و 3 فقط صحيحتان", "العبارات 1 و 2 و 3 جميعها صحيحة", "العبارتان 1 و 3 فقط صحيحتان", "العبارتان 1 و 2 فقط صحيحتان"]', '[3]', 'العبارتان 1 و2 صحيحتان؛ أما عاصمة المناذرة فهي الحيرة.', 'UGC NET Arabic', 'الوحدة ١ · اللغة العربية وأصلها والشعر من الجاهلية إلى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100022, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - دارت حرب البسوس بين بكر وتغلب
2 - قُتل كليب على يد مهلهل
3 - كان كليب أخا مهلهل', '["العبارات 1 و 2 و 3 جميعها صحيحة", "العبارة 1 فقط صحيحة", "العبارتان 1 و 3 فقط صحيحتان", "العبارة 2 فقط صحيحة"]', '[2]', 'العبارة 2 خاطئة؛ إذ قتل جساس بن مرة كليبًا، وكان كليب أخا مهلهل.', 'UGC NET Arabic', 'الوحدة ١ · اللغة العربية وأصلها والشعر من الجاهلية إلى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100023, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - معلقة زهير بن أبي سلمى ميمية من الطويل
2 - مطلع معلقة عنترة «هل غادر الشعراء من متردم»
3 - جمع ديوان امرئ القيس وأضاف الحواشي حسن السندوبي', '["العبارة 1 فقط صحيحة", "العبارة 2 فقط صحيحة", "العبارات 1 و 2 و 3 جميعها صحيحة", "العبارتان 1 و 3 فقط صحيحتان"]', '[2]', 'العبارات الثلاث صحيحة.', 'UGC NET Arabic', 'الوحدة ١ · اللغة العربية وأصلها والشعر من الجاهلية إلى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100024, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - اسم الحطيئة عمرو بن أوس
2 - اشترى عمر رضي الله عنه من الحطيئة أعراض المسلمين بثلاثة آلاف درهم
3 - أسلم الحطيئة بعد فتح مكة ثم ارتد في حرب الردة', '["العبارتان 1 و 3 فقط صحيحتان", "العبارة 3 فقط صحيحة", "العبارة 2 فقط صحيحة", "العبارتان 2 و 3 فقط صحيحتان"]', '[3]', 'اسم الحطيئة جرول بن أوس، فالعبارة 1 خاطئة.', 'UGC NET Arabic', 'الوحدة ١ · اللغة العربية وأصلها والشعر من الجاهلية إلى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100025, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - قال جرير: «أنا لولا الخنساء»
2 - اشتهرت الخنساء بشعر الغزل
3 - الخنساء من قبيلة تغلب', '["العبارتان 1 و 2 فقط صحيحتان", "العبارة 1 فقط صحيحة", "العبارتان 2 و 3 فقط صحيحتان", "العبارتان 1 و 3 فقط صحيحتان"]', '[1]', 'اشتهرت الخنساء بالرثاء، وهي سلمية لا تغلبية؛ فالعبارة 1 فقط صحيحة.', 'UGC NET Arabic', 'الوحدة ١ · اللغة العربية وأصلها والشعر من الجاهلية إلى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100026, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - امرؤ القيس من قبيلة تغلب
2 - أبو امرئ القيس حجر ملك بني أسد وغطفان
3 - شرح ديوان امرئ القيس عبد الرحمن البرقوقي', '["العبارتان 1 و 3 فقط صحيحتان", "العبارتان 2 و 3 فقط صحيحتان", "العبارة 1 فقط صحيحة", "العبارة 2 فقط صحيحة"]', '[3]', 'امرؤ القيس من كندة، والبرقوقي شرح ديوان حسان؛ فالعبارة 2 فقط صحيحة.', 'UGC NET Arabic', 'الوحدة ١ · اللغة العربية وأصلها والشعر من الجاهلية إلى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100027, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - جميل بن معمر رائد الشعر الهجائي
2 - اسم الفرزدق جرير بن عطية
3 - طُبع كتاب النقائض بين جرير والفرزدق في ليدن', '["العبارة 1 فقط صحيحة", "العبارة 2 فقط صحيحة", "العبارتان 2 و 3 فقط صحيحتان", "العبارة 3 فقط صحيحة"]', '[3]', 'جميل رائد الحب العذري، واسم الفرزدق همام بن غالب؛ فالعبارة 3 فقط صحيحة.', 'UGC NET Arabic', 'الوحدة ١ · اللغة العربية وأصلها والشعر من الجاهلية إلى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100028, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - بشار بن برد شاعر أعمى فارسي الأصل
2 - لُقّب أبو نواس بشاعر الخمر
3 - أبو نواس من شعراء العصر الأموي', '["العبارة 2 فقط صحيحة", "العبارات 1 و 2 و 3 جميعها صحيحة", "العبارتان 1 و 2 فقط صحيحتان", "العبارة 3 فقط صحيحة"]', '[2]', 'أبو نواس من شعراء العصر العباسي.', 'UGC NET Arabic', 'الوحدة ١ · اللغة العربية وأصلها والشعر من الجاهلية إلى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100029, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - شعر البحتري متفاوت وشعر أبي تمام مستوٍ
2 - «الوحشيات» هي الحماسة الصغرى لأبي تمام
3 - معنى كلمة «البحتري» قصير القامة', '["العبارتان 1 و 3 فقط صحيحتان", "العبارة 3 فقط صحيحة", "العبارتان 2 و 3 فقط صحيحتان", "العبارة 2 فقط صحيحة"]', '[2]', 'شعر أبي تمام متفاوت وشعر البحتري مستوٍ؛ فالعبارة 1 خاطئة.', 'UGC NET Arabic', 'الوحدة ١ · اللغة العربية وأصلها والشعر من الجاهلية إلى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100030, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - ابن الرومي رومي الأصل
2 - أشهر هجاء المتنبي لاميته في سيف الدولة
3 - «الإبانة عن سرقات المتنبي لفظًا ومعنى» لأبي سعيد العبيدي', '["العبارة 2 فقط صحيحة", "العبارتان 1 و 3 فقط صحيحتان", "العبارات 1 و 2 و 3 جميعها صحيحة", "العبارتان 2 و 3 فقط صحيحتان"]', '[1]', 'أشهر هجاء المتنبي دالّيته في كافور؛ فالعبارة 2 خاطئة.', 'UGC NET Arabic', 'الوحدة ١ · اللغة العربية وأصلها والشعر من الجاهلية إلى العصر العباسي', 'medium');
INSERT OR IGNORE INTO quizzes (id, title, description, instructions, subject, topic, difficulty, status, mode, duration_minutes, attempt_limit, pass_mark, marks_per_question, negative_marks, shuffle_questions, shuffle_options, show_answers, access_type, published_at) VALUES (1002, 'الوحدة ١ — أسئلة العبارات', 'اللغة العربية وأصلها والشعر من الجاهلية إلى العصر العباسي', 'اقرأ العبارات في كل سؤال، ثم اختر الخيار الذي يحدد العبارات الصحيحة. لكل سؤال درجتان ولا خصم على الإجابة الخاطئة.', 'UGC NET Arabic', 'اللغة العربية وأصلها والشعر من الجاهلية إلى العصر العباسي', 'medium', 'published', 'both', 15, 0, 40, 2, 0, 0, 0, 1, 'free', datetime('now'));
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1002, 100021, 0);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1002, 100022, 1);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1002, 100023, 2);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1002, 100024, 3);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1002, 100025, 4);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1002, 100026, 5);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1002, 100027, 6);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1002, 100028, 7);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1002, 100029, 8);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1002, 100030, 9);

INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100031, 'mcq', 'الذي يوصف بأنه أسقف نجران وخطيب العرب وحكيمها هو:', '["زياد بن أبيه", "قس بن ساعدة", "الحجاج بن يوسف", "أكثم بن صيفي"]', '[1]', 'قس بن ساعدة خطيب العرب وحكيمها في الجاهلية.', 'UGC NET Arabic', 'الوحدة ٢ · النثر العربي حتى العصر العباسي', 'easy');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100032, 'mcq', 'أول من قال «أما بعد»، كما ورد في الكتاب، هو:', '["علي بن أبي طالب", "عبد الحميد الكاتب", "الحجاج بن يوسف", "قس بن ساعدة"]', '[3]', 'يُذكر أن قسًّا أول من خطب متكئًا على سيف أو عصا، وأول من قال «أما بعد».', 'UGC NET Arabic', 'الوحدة ٢ · النثر العربي حتى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100033, 'mcq', 'ألقى قس بن ساعدة خطبته المشهورة في سوق:', '["مجنة", "ذي المجاز", "عكاظ", "المربد"]', '[2]', 'خطبته: «أيها الناس، اسمعوا وعوا؛ إنه من عاش مات، ومن مات فات».', 'UGC NET Arabic', 'الوحدة ٢ · النثر العربي حتى العصر العباسي', 'easy');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100034, 'mcq', 'أشهر حكام العرب في الجاهلية على الإطلاق هو:', '["قس بن ساعدة", "زهير بن أبي سلمى", "أكثم بن صيفي", "عمرو بن كلثوم"]', '[2]', 'أكثم بن صيفي التميمي حكيم العرب وحاكمهم.', 'UGC NET Arabic', 'الوحدة ٢ · النثر العربي حتى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100035, 'mcq', 'قال كسرى لأكثم بن صيفي: «لو لم يكن للعرب غيرك لكفى»، والقائل هو:', '["كسرى", "النعمان بن المنذر", "قيصر", "عمرو بن هند"]', '[0]', 'بلغ إعجاب كسرى بأكثم أن قال له ذلك.', 'UGC NET Arabic', 'الوحدة ٢ · النثر العربي حتى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100036, 'mcq', 'لُقّب بـ«وليد الكعبة» لأنه وُلد في جوفها:', '["عمر بن الخطاب", "حمزة بن عبد المطلب", "علي بن أبي طالب", "عثمان بن عفان"]', '[2]', 'من ألقاب علي: وليد الكعبة وأسد الله وأبو تراب والمرتضى.', 'UGC NET Arabic', 'الوحدة ٢ · النثر العربي حتى العصر العباسي', 'easy');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100037, 'mcq', 'جمع «نهج البلاغة» ونسبه إلى علي بن أبي طالب:', '["الشريف الرضي", "ابن المقفع", "الجاحظ", "الصاحب بن عباد"]', '[0]', 'مرجع أدب علي نهج البلاغة الذي جمعه الشريف الرضي.', 'UGC NET Arabic', 'الوحدة ٢ · النثر العربي حتى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100038, 'mcq', '«الخطبة البتراء» من خطب:', '["زياد بن أبيه", "علي بن أبي طالب", "الحجاج بن يوسف", "طارق بن زياد"]', '[0]', 'خطبة زياد البتراء أشبه بالتصريحات السياسية الحضارية.', 'UGC NET Arabic', 'الوحدة ٢ · النثر العربي حتى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100039, 'mcq', 'الذي حثّ أبا الأسود الدؤلي على أن يضع كتابًا في النحو هو:', '["معاوية بن أبي سفيان", "زياد بن أبيه", "عبد الملك بن مروان", "الحجاج بن يوسف"]', '[1]', 'زياد بن أبيه والي البصرة ثم العراق.', 'UGC NET Arabic', 'الوحدة ٢ · النثر العربي حتى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100040, 'mcq', 'القائل: «إني لأرى رؤوسًا قد أينعت وقد حان قطافها» هو:', '["قس بن ساعدة", "الحجاج بن يوسف", "زياد بن أبيه", "طارق بن زياد"]', '[1]', 'من خطبته المشهورة في أهل العراق.', 'UGC NET Arabic', 'الوحدة ٢ · النثر العربي حتى العصر العباسي', 'easy');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100041, 'mcq', 'فاتح الأندلس هو القائد:', '["موسى بن نصير", "عقبة بن نافع", "قتيبة بن مسلم", "طارق بن زياد"]', '[3]', 'اشتهر طارق بن زياد بخطبته عند فتح الأندلس.', 'UGC NET Arabic', 'الوحدة ٢ · النثر العربي حتى العصر العباسي', 'easy');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100042, 'mcq', 'اللقب الذي عُرف به عبد الحميد الكاتب هو:', '["أستاذ المترسّلين", "شاعر الخمر", "كافي الكفاة", "أمير الكتابة"]', '[0]', 'هو رأس المدرسة الفنية في الكتابة العربية.', 'UGC NET Arabic', 'الوحدة ٢ · النثر العربي حتى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100043, 'mcq', 'أول من أنشأ فن الرسائل في الأدب العربي هو:', '["ابن العميد", "القاضي الفاضل", "عبد الحميد الكاتب", "الجاحظ"]', '[2]', 'قال ابن النديم: هو الذي سبّل سبيل البلاغة في الترسل.', 'UGC NET Arabic', 'الوحدة ٢ · النثر العربي حتى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100044, 'mcq', 'قيل: «بدئت الكتابة بعبد الحميد وختمت بـ»:', '["الجاحظ", "القاضي الفاضل", "بديع الزمان", "ابن العميد"]', '[3]', 'قال الثعالبي ذلك في وصف أسلوب ابن العميد.', 'UGC NET Arabic', 'الوحدة ٢ · النثر العربي حتى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100045, 'mcq', 'عُرف عمرو بن بحر بالجاحظ بسبب:', '["سرعة حفظه", "جحوظ عينيه", "كثرة كتبه", "شدة بخله"]', '[1]', 'لقب بالجاحظ لجحوظ عينيه، واشتهر بقبح خلقته.', 'UGC NET Arabic', 'الوحدة ٢ · النثر العربي حتى العصر العباسي', 'easy');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100046, 'mcq', 'يُروى أن الجاحظ مات:', '["في السجن", "بسقوط الكتب عليه", "غرقًا في البحر", "في ساحة القتال"]', '[1]', 'أصيب بداء النقرس وسقطت عليه الكتب فمات.', 'UGC NET Arabic', 'الوحدة ٢ · النثر العربي حتى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100047, 'mcq', 'يُلقب الصاحب بن عباد بـ:', '["رأس البديعيين", "أستاذ المترسلين", "كافي الكفاة", "بديع الزمان"]', '[2]', 'من نوادر الوزراء الذين غلب عليهم العلم، وكان محدثًا وشاعرًا ووزيرًا.', 'UGC NET Arabic', 'الوحدة ٢ · النثر العربي حتى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100048, 'mcq', 'اشتهر بديع الزمان الهمذاني بنثره من:', '["القصص الشعبية", "كتب الرحلات", "الخطب السياسية", "الرسائل والمقامات"]', '[3]', 'نثره رسائل ومقامات ورسائل إخوانية، واتصل بالصاحب بن عباد.', 'UGC NET Arabic', 'الوحدة ٢ · النثر العربي حتى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100049, 'mcq', 'ألّف ابن فارس كتاب «الصاحبي» للصاحب:', '["بن الرومي", "بن عباد", "بن العميد", "بن زيدون"]', '[1]', 'ألف ابن فارس «الصاحبي» في فقه اللغة للصاحب بن عباد.', 'UGC NET Arabic', 'الوحدة ٢ · النثر العربي حتى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100050, 'mcq', 'القصة المحورية (قصة الإطار) في «ألف ليلة وليلة» هي قصة:', '["علاء الدين", "علي بابا", "شهرزاد", "السندباد"]', '[2]', 'أُضيفت إليها قصة شهرزاد وتُعد القصة المحورية للكتاب.', 'UGC NET Arabic', 'الوحدة ٢ · النثر العربي حتى العصر العباسي', 'easy');
INSERT OR IGNORE INTO quizzes (id, title, description, instructions, subject, topic, difficulty, status, mode, duration_minutes, attempt_limit, pass_mark, marks_per_question, negative_marks, shuffle_questions, shuffle_options, show_answers, access_type, published_at) VALUES (1003, 'الوحدة ٢ — اختيار من متعدد', 'النثر العربي حتى العصر العباسي', 'اقرأ كل سؤال بعناية ثم اختر إجابة واحدة صحيحة. لكل سؤال درجتان ولا خصم على الإجابة الخاطئة.', 'UGC NET Arabic', 'النثر العربي حتى العصر العباسي', 'medium', 'published', 'both', 20, 0, 40, 2, 0, 0, 0, 1, 'free', datetime('now'));
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1003, 100031, 0);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1003, 100032, 1);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1003, 100033, 2);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1003, 100034, 3);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1003, 100035, 4);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1003, 100036, 5);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1003, 100037, 6);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1003, 100038, 7);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1003, 100039, 8);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1003, 100040, 9);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1003, 100041, 10);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1003, 100042, 11);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1003, 100043, 12);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1003, 100044, 13);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1003, 100045, 14);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1003, 100046, 15);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1003, 100047, 16);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1003, 100048, 17);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1003, 100049, 18);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1003, 100050, 19);

INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100051, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - قس بن ساعدة أسقف نجران وخطيب العرب وحكيمها
2 - ألقى قس خطبته المشهورة في سوق عكاظ
3 - أول من قال «أما بعد» أكثم بن صيفي', '["العبارتان 2 و 3 فقط صحيحتان", "العبارة 1 فقط صحيحة", "العبارتان 1 و 2 فقط صحيحتان", "العبارات 1 و 2 و 3 جميعها صحيحة"]', '[2]', 'ورد في الكتاب أن قسًّا أول من قال «أما بعد».', 'UGC NET Arabic', 'الوحدة ٢ · النثر العربي حتى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100052, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - أكثم بن صيفي من خطباء العصر الأموي
2 - قال كسرى لأكثم: «لو لم يكن للعرب غيرك لكفى»
3 - من أقواله: «تباعدوا في الدار، تقاربوا في المودة»', '["العبارتان 1 و 3 فقط صحيحتان", "العبارة 3 فقط صحيحة", "العبارتان 2 و 3 فقط صحيحتان", "العبارات 1 و 2 و 3 جميعها صحيحة"]', '[2]', 'أكثم من حكماء العصر الجاهلي؛ فالعبارة 1 خاطئة.', 'UGC NET Arabic', 'الوحدة ٢ · النثر العربي حتى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100053, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - لُقّب علي بن أبي طالب بوليد الكعبة
2 - جمع الشريف الرضي نهج البلاغة
3 - قال عمر بن عبد العزيز: «أزهد الناس في دنيا علي بن أبي طالب»', '["العبارات 1 و 2 و 3 جميعها صحيحة", "العبارة 3 فقط صحيحة", "العبارتان 1 و 3 فقط صحيحتان", "العبارتان 1 و 2 فقط صحيحتان"]', '[0]', 'العبارات الثلاث صحيحة.', 'UGC NET Arabic', 'الوحدة ٢ · النثر العربي حتى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100054, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - ولّى معاوية زيادًا البصرة ثم ضمّ إليه الكوفة
2 - تُسمّى خطبة زياد المشهورة «الخطبة الغراء»
3 - حثّ زياد أبا الأسود على وضع كتاب في النحو', '["العبارتان 2 و 3 فقط صحيحتان", "العبارة 1 فقط صحيحة", "العبارتان 1 و 3 فقط صحيحتان", "العبارتان 1 و 2 فقط صحيحتان"]', '[2]', 'تُسمّى خطبته «البتراء»؛ فالعبارة 2 خاطئة.', 'UGC NET Arabic', 'الوحدة ٢ · النثر العربي حتى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100055, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - وُلد الحجاج بن يوسف في دمشق
2 - قال الحجاج: «إني لأرى رؤوسًا قد أينعت وقد حان قطافها»
3 - توفي الحجاج في الكوفة', '["العبارتان 1 و 2 فقط صحيحتان", "العبارة 3 فقط صحيحة", "العبارة 2 فقط صحيحة", "العبارتان 1 و 3 فقط صحيحتان"]', '[2]', 'وُلد الحجاج في الطائف وتوفي في واسط؛ فالعبارة 2 فقط صحيحة.', 'UGC NET Arabic', 'الوحدة ٢ · النثر العربي حتى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100056, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - فتح طارق بن زياد العراق
2 - لُقّب عبد الحميد الكاتب بالجاحظ
3 - عبد الحميد الكاتب أول من أنشأ فن الرسائل', '["العبارات 1 و 2 و 3 جميعها صحيحة", "العبارتان 1 و 3 فقط صحيحتان", "العبارة 3 فقط صحيحة", "العبارتان 1 و 2 فقط صحيحتان"]', '[2]', 'طارق فاتح الأندلس، والجاحظ هو عمرو بن بحر؛ فالعبارة 3 فقط صحيحة.', 'UGC NET Arabic', 'الوحدة ٢ · النثر العربي حتى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100057, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - لُقّب الجاحظ بهذا الاسم لجحوظ عينيه
2 - الجاحظ أول عالم عربي جمع بين الجد والهزل
3 - كتاب «البخلاء» في الفلسفة والاعتزال والدين', '["العبارتان 1 و 2 فقط صحيحتان", "العبارة 2 فقط صحيحة", "العبارتان 1 و 3 فقط صحيحتان", "العبارة 1 فقط صحيحة"]', '[0]', '«البخلاء» كتاب في الأدب؛ فالعبارة 3 خاطئة.', 'UGC NET Arabic', 'الوحدة ٢ · النثر العربي حتى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100058, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - ابن العميد من الطبقة الأولى من الكتّاب
2 - كان الصاحب بن عباد من أتباع ابن العميد
3 - ألّف ابن فارس «الصاحبي» للصاحب بن عباد', '["العبارتان 2 و 3 فقط صحيحتان", "العبارات 1 و 2 و 3 جميعها صحيحة", "العبارة 1 فقط صحيحة", "العبارتان 1 و 3 فقط صحيحتان"]', '[0]', 'ابن العميد إمام الطبقة الثالثة؛ فالعبارة 1 خاطئة.', 'UGC NET Arabic', 'الوحدة ٢ · النثر العربي حتى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100059, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - اشتهر بديع الزمان بنثره من رسائل ومقامات
2 - الحريري كاتب مقلّ وشاعر مكثر
3 - اتصل بديع الزمان بالصاحب بن عباد', '["العبارتان 1 و 3 فقط صحيحتان", "العبارتان 1 و 2 فقط صحيحتان", "العبارة 3 فقط صحيحة", "العبارة 2 فقط صحيحة"]', '[0]', 'الحريري كاتب مكثر وشاعر مقلّ؛ فالعبارة 2 خاطئة.', 'UGC NET Arabic', 'الوحدة ٢ · النثر العربي حتى العصر العباسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100060, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - نقل العرب «ألف ليلة وليلة» من الفارسية
2 - قصة شهرزاد هي القصة المحورية في الكتاب
3 - أصل «كليلة ودمنة» عربي', '["العبارة 3 فقط صحيحة", "العبارتان 1 و 2 فقط صحيحتان", "العبارتان 2 و 3 فقط صحيحتان", "العبارة 2 فقط صحيحة"]', '[1]', '«كليلة ودمنة» ليس عربي الأصل، بل نُقل عن الفارسية والهندية؛ فالعبارة 3 خاطئة.', 'UGC NET Arabic', 'الوحدة ٢ · النثر العربي حتى العصر العباسي', 'medium');
INSERT OR IGNORE INTO quizzes (id, title, description, instructions, subject, topic, difficulty, status, mode, duration_minutes, attempt_limit, pass_mark, marks_per_question, negative_marks, shuffle_questions, shuffle_options, show_answers, access_type, published_at) VALUES (1004, 'الوحدة ٢ — أسئلة العبارات', 'النثر العربي حتى العصر العباسي', 'اقرأ العبارات في كل سؤال، ثم اختر الخيار الذي يحدد العبارات الصحيحة. لكل سؤال درجتان ولا خصم على الإجابة الخاطئة.', 'UGC NET Arabic', 'النثر العربي حتى العصر العباسي', 'medium', 'published', 'both', 15, 0, 40, 2, 0, 0, 0, 1, 'free', datetime('now'));
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1004, 100051, 0);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1004, 100052, 1);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1004, 100053, 2);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1004, 100054, 3);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1004, 100055, 4);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1004, 100056, 5);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1004, 100057, 6);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1004, 100058, 7);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1004, 100059, 8);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1004, 100060, 9);

INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100061, 'mcq', 'وُلد جبران خليل جبران في بلدة:', '["زحلة", "بسكنتا", "بشرّي (شمال لبنان)", "المحيدثة"]', '[2]', 'وُلد جبران في بشرّي لأسرة مارونية فقيرة.', 'UGC NET Arabic', 'الوحدة ٣ · أدب المهجر والأدب الأندلسي', 'easy');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100062, 'mcq', 'الكتاب الذي ترجم إلى عشرات اللغات من مؤلفات جبران هو:', '["آلهة الأرض", "المواكب", "النبي", "العواصف"]', '[2]', '«النبي» من أشهر كتب جبران وقد ترجم إلى عشرات اللغات.', 'UGC NET Arabic', 'الوحدة ٣ · أدب المهجر والأدب الأندلسي', 'easy');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100063, 'mcq', 'مجموعة مقالات جبران الثائرة جُمعت في كتاب:', '["دمعة وابتسامة", "العواصف", "البدائع والطرائف", "الأجنحة المتكسرة"]', '[1]', 'كتب مقالاته الثائرة ثم جمعت في «العواصف».', 'UGC NET Arabic', 'الوحدة ٣ · أدب المهجر والأدب الأندلسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100064, 'mcq', 'يُعرف إيليا أبو ماضي بأنه شاعر:', '["الحكمة", "البطولة", "التفاؤل", "الخمر"]', '[2]', 'اشتهر بتفاؤله في الحياة وحيرته الفلسفية.', 'UGC NET Arabic', 'الوحدة ٣ · أدب المهجر والأدب الأندلسي', 'easy');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100065, 'mcq', 'ديوان «الجداول» للشاعر:', '["إيليا أبو ماضي", "رشيد أيوب", "إلياس فرحات", "نسيب عريضة"]', '[0]', '«الجداول» من دواوين أبي ماضي المهجرية.', 'UGC NET Arabic', 'الوحدة ٣ · أدب المهجر والأدب الأندلسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100066, 'mcq', 'يوصف بأنه «شاعر الدرويش» و«الشاعر الشاكي»:', '["إلياس فرحات", "نسيب عريضة", "رشيد أيوب", "ميخائيل نعيمة"]', '[2]', 'ديوانه «الأيوبيات» يغلب عليه الشكوى وحب الحرية.', 'UGC NET Arabic', 'الوحدة ٣ · أدب المهجر والأدب الأندلسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100067, 'mcq', 'كتاب «مرداد» من مؤلفات:', '["إيليا أبو ماضي", "نسيب عريضة", "جبران خليل جبران", "ميخائيل نعيمة"]', '[3]', '«مرداد» خطب ودروس يلقيها مرداد على مريديه.', 'UGC NET Arabic', 'الوحدة ٣ · أدب المهجر والأدب الأندلسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100068, 'mcq', 'أمضى ميخائيل نعيمة أوقاته في لبنان في الشخروب بجانب:', '["بسكنتا", "صيدا", "طرابلس", "بشرّي"]', '[0]', 'ارتبط نعيمة ببسكنتا وبالشخروب.', 'UGC NET Arabic', 'الوحدة ٣ · أدب المهجر والأدب الأندلسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100069, 'mcq', 'يُعرف رشيد سليم الخوري بلقب:', '["شاعر الخمر", "الشاعر القروي", "شاعر الرسول", "شاعر النيل"]', '[1]', 'لقب أيضًا بشاعر العروبة.', 'UGC NET Arabic', 'الوحدة ٣ · أدب المهجر والأدب الأندلسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100070, 'mcq', '«الرشديات» أول مجموعة شعرية للشاعر القروي، وطُبعت في:', '["البرازيل", "القاهرة", "باريس", "نيويورك"]', '[0]', 'طبعت في البرازيل ضمن أدب المهجر الجنوبي.', 'UGC NET Arabic', 'الوحدة ٣ · أدب المهجر والأدب الأندلسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100071, 'mcq', 'أول رئيس للعصبة الأندلسية في البرازيل هو:', '["رشيد أيوب", "إلياس فرحات", "ميشال معلوف", "جبران خليل جبران"]', '[2]', 'تأسست العصبة الأندلسية في البرازيل وكان معلوف أول رئيس لها.', 'UGC NET Arabic', 'الوحدة ٣ · أدب المهجر والأدب الأندلسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100072, 'mcq', 'اسم «الموشح» مأخوذ من:', '["وسام الشعراء", "وشاية الحُسّاد", "وشاح المرأة", "ثوب الراقصات"]', '[2]', 'الوشاح قلادة تلبسها المرأة.', 'UGC NET Arabic', 'الوحدة ٣ · أدب المهجر والأدب الأندلسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100073, 'mcq', 'يُسمّى القفل الأخير في الموشح:', '["الغصن", "المطلع", "الدور", "الخرجة"]', '[3]', 'الخرجة هي القفل الأخير من الموشح.', 'UGC NET Arabic', 'الوحدة ٣ · أدب المهجر والأدب الأندلسي', 'easy');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100074, 'mcq', 'موشحة «جادك الغيث إذا الغيث همى» من نظم:', '["لسان الدين بن الخطيب", "ابن زيدون", "ابن خفاجة", "ابن زمرك"]', '[0]', 'من أشهر الموشحات الأندلسية.', 'UGC NET Arabic', 'الوحدة ٣ · أدب المهجر والأدب الأندلسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100075, 'mcq', 'يُلقب ابن خفاجة بـ:', '["شاعر الغزل", "بحتري الغرب", "أمير الشعراء", "شاعر الجنان والمتنزهات"]', '[3]', 'وصف الحدائق والرياض حتى لُقّب بالجنّان.', 'UGC NET Arabic', 'الوحدة ٣ · أدب المهجر والأدب الأندلسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100076, 'mcq', 'يُعرف ابن زيدون بـ:', '["شاعر الجنان", "أبي تمام الأندلس", "بحتري الغرب", "متنبي الغرب"]', '[2]', 'عُرف بأمير صناعتين (الشعر والنثر) وببحتري الغرب.', 'UGC NET Arabic', 'الوحدة ٣ · أدب المهجر والأدب الأندلسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100077, 'mcq', 'ولادة بنت المستكفي ابنة الخليفة الأموي:', '["الحكم المستنصر", "عبد الرحمن الناصر", "المعتضد بن عباد", "محمد بن عبد الرحمن (المستكفي بالله)"]', '[3]', 'اشتهرت بصالونها الأدبي في قرطبة.', 'UGC NET Arabic', 'الوحدة ٣ · أدب المهجر والأدب الأندلسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100078, 'mcq', 'صاحب كتاب «العقد الفريد» هو:', '["ابن خلدون", "ابن قتيبة", "ابن عبد ربه", "المبرد"]', '[2]', 'ألّفه على نسق «عيون الأخبار» لابن قتيبة.', 'UGC NET Arabic', 'الوحدة ٣ · أدب المهجر والأدب الأندلسي', 'easy');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100079, 'mcq', '«رسالة التوابع والزوابع» من تأليف:', '["ابن حزم", "ابن شهيد الأندلسي", "ابن طفيل", "ابن زيدون"]', '[1]', 'من رسائل الفكاهة والتعريض عنده.', 'UGC NET Arabic', 'الوحدة ٣ · أدب المهجر والأدب الأندلسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100080, 'mcq', 'كتاب «المحلى بالآثار» لـ:', '["ابن حزم", "ابن طفيل", "ابن رشد", "ابن عبد ربه"]', '[0]', 'ولد ابن حزم في قرطبة، ومن أعماله «المحلى» و«الفصل في الملل والأهواء والنحل».', 'UGC NET Arabic', 'الوحدة ٣ · أدب المهجر والأدب الأندلسي', 'medium');
INSERT OR IGNORE INTO quizzes (id, title, description, instructions, subject, topic, difficulty, status, mode, duration_minutes, attempt_limit, pass_mark, marks_per_question, negative_marks, shuffle_questions, shuffle_options, show_answers, access_type, published_at) VALUES (1005, 'الوحدة ٣ — اختيار من متعدد', 'أدب المهجر والأدب الأندلسي', 'اقرأ كل سؤال بعناية ثم اختر إجابة واحدة صحيحة. لكل سؤال درجتان ولا خصم على الإجابة الخاطئة.', 'UGC NET Arabic', 'أدب المهجر والأدب الأندلسي', 'medium', 'published', 'both', 20, 0, 40, 2, 0, 0, 0, 1, 'free', datetime('now'));
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1005, 100061, 0);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1005, 100062, 1);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1005, 100063, 2);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1005, 100064, 3);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1005, 100065, 4);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1005, 100066, 5);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1005, 100067, 6);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1005, 100068, 7);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1005, 100069, 8);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1005, 100070, 9);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1005, 100071, 10);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1005, 100072, 11);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1005, 100073, 12);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1005, 100074, 13);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1005, 100075, 14);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1005, 100076, 15);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1005, 100077, 16);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1005, 100078, 17);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1005, 100079, 18);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1005, 100080, 19);

INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100081, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - وُلد جبران في بلدة بشرّي
2 - «العواصف» مجموعة مقالات ثائرة
3 - كتب جبران «النبي» بالعربية', '["العبارة 2 فقط صحيحة", "العبارة 1 فقط صحيحة", "العبارات 1 و 2 و 3 جميعها صحيحة", "العبارتان 1 و 2 فقط صحيحتان"]', '[3]', 'كتب جبران «النبي» بالإنجليزية.', 'UGC NET Arabic', 'الوحدة ٣ · أدب المهجر والأدب الأندلسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100082, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - ديوان «الجداول» لرشيد أيوب
2 - شارك أبو ماضي في تأسيس الرابطة القلمية
3 - لُقّب أبو ماضي بشاعر التفاؤل', '["العبارات 1 و 2 و 3 جميعها صحيحة", "العبارة 3 فقط صحيحة", "العبارتان 2 و 3 فقط صحيحتان", "العبارة 2 فقط صحيحة"]', '[2]', '«الجداول» لأبي ماضي؛ فالعبارة 1 خاطئة.', 'UGC NET Arabic', 'الوحدة ٣ · أدب المهجر والأدب الأندلسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100083, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - «الأيوبيات» ديوان لرشيد أيوب
2 - ميخائيل نعيمة من أدباء الأندلس
3 - «مرداد» من كتب نعيمة', '["العبارة 3 فقط صحيحة", "العبارتان 1 و 3 فقط صحيحتان", "العبارة 2 فقط صحيحة", "العبارة 1 فقط صحيحة"]', '[1]', 'نعيمة من أدباء المهجر لا الأندلس.', 'UGC NET Arabic', 'الوحدة ٣ · أدب المهجر والأدب الأندلسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100084, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - الموشح مأخوذ اسمه من وشاح المرأة
2 - الخرجة هي القفل الأخير من الموشح
3 - ابن زمرك من الوشّاحين', '["العبارة 2 فقط صحيحة", "العبارتان 1 و 3 فقط صحيحتان", "العبارتان 1 و 2 فقط صحيحتان", "العبارات 1 و 2 و 3 جميعها صحيحة"]', '[3]', 'العبارات الثلاث صحيحة.', 'UGC NET Arabic', 'الوحدة ٣ · أدب المهجر والأدب الأندلسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100085, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - «جادك الغيث» موشحة ابن زيدون
2 - لُقّب ابن خفاجة بالجنّان
3 - عاش ابن خفاجة في عصر الموحدين', '["العبارة 3 فقط صحيحة", "العبارة 1 فقط صحيحة", "العبارة 2 فقط صحيحة", "العبارات 1 و 2 و 3 جميعها صحيحة"]', '[2]', 'الموشحة للسان الدين بن الخطيب، وابن خفاجة في عصر المرابطين؛ فالعبارة 2 فقط صحيحة.', 'UGC NET Arabic', 'الوحدة ٣ · أدب المهجر والأدب الأندلسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100086, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - يُعرف ابن زيدون ببحتري الغرب
2 - عشق ابن زيدون حفصة بنت الحاج
3 - ولادة ابنة الحاجب المنصور', '["العبارة 2 فقط صحيحة", "العبارات 1 و 2 و 3 جميعها صحيحة", "العبارة 1 فقط صحيحة", "العبارة 3 فقط صحيحة"]', '[2]', 'عشق ابن زيدون ولادة بنت المستكفي؛ فالعبارة 1 فقط صحيحة.', 'UGC NET Arabic', 'الوحدة ٣ · أدب المهجر والأدب الأندلسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100087, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - ابن عبد ربه صاحب «التوابع والزوابع»
2 - وُلد ابن حزم في إشبيلية
3 - ألّف ابن عبد ربه «العقد الفريد»', '["العبارة 1 فقط صحيحة", "العبارتان 1 و 2 فقط صحيحتان", "العبارتان 1 و 3 فقط صحيحتان", "العبارة 3 فقط صحيحة"]', '[3]', '«التوابع» لابن شهيد، وابن حزم قرطبي؛ فالعبارة 3 فقط صحيحة.', 'UGC NET Arabic', 'الوحدة ٣ · أدب المهجر والأدب الأندلسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100088, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - وُلد ابن طفيل في وادي آش قرب غرناطة
2 - توفي ابن طفيل في مراكش
3 - ابن طفيل صاحب «الفصل في الملل والأهواء والنحل»', '["العبارتان 1 و 2 فقط صحيحتان", "العبارة 2 فقط صحيحة", "العبارة 3 فقط صحيحة", "العبارة 1 فقط صحيحة"]', '[0]', '«الفصل» لابن حزم.', 'UGC NET Arabic', 'الوحدة ٣ · أدب المهجر والأدب الأندلسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100089, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - أُسست الرابطة القلمية في البرازيل
2 - كان جبران ونعيمة من مؤسسي الرابطة القلمية
3 - تأسست العصبة الأندلسية في البرازيل', '["العبارتان 2 و 3 فقط صحيحتان", "العبارات 1 و 2 و 3 جميعها صحيحة", "العبارتان 1 و 3 فقط صحيحتان", "العبارة 2 فقط صحيحة"]', '[0]', 'الرابطة القلمية أُسست في نيويورك؛ فالعبارة 1 خاطئة.', 'UGC NET Arabic', 'الوحدة ٣ · أدب المهجر والأدب الأندلسي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100090, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - «الشاعر القروي» لقب رشيد سليم الخوري
2 - «الرشديات» آخر مجموعة شعرية له
3 - ميشال معلوف أول رئيس للعصبة الأندلسية', '["العبارتان 2 و 3 فقط صحيحتان", "العبارات 1 و 2 و 3 جميعها صحيحة", "العبارتان 1 و 3 فقط صحيحتان", "العبارة 2 فقط صحيحة"]', '[2]', '«الرشديات» أول مجموعة شعرية له.', 'UGC NET Arabic', 'الوحدة ٣ · أدب المهجر والأدب الأندلسي', 'medium');
INSERT OR IGNORE INTO quizzes (id, title, description, instructions, subject, topic, difficulty, status, mode, duration_minutes, attempt_limit, pass_mark, marks_per_question, negative_marks, shuffle_questions, shuffle_options, show_answers, access_type, published_at) VALUES (1006, 'الوحدة ٣ — أسئلة العبارات', 'أدب المهجر والأدب الأندلسي', 'اقرأ العبارات في كل سؤال، ثم اختر الخيار الذي يحدد العبارات الصحيحة. لكل سؤال درجتان ولا خصم على الإجابة الخاطئة.', 'UGC NET Arabic', 'أدب المهجر والأدب الأندلسي', 'medium', 'published', 'both', 15, 0, 40, 2, 0, 0, 0, 1, 'free', datetime('now'));
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1006, 100081, 0);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1006, 100082, 1);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1006, 100083, 2);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1006, 100084, 3);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1006, 100085, 4);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1006, 100086, 5);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1006, 100087, 6);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1006, 100088, 7);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1006, 100089, 8);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1006, 100090, 9);

INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100091, 'mcq', 'الناقد الجاهلي الذي كانت له قبة حمراء في سوق عكاظ هو:', '["النابغة الذبياني", "الأعشى", "امرؤ القيس", "زهير بن أبي سلمى"]', '[0]', 'كان النابغة يحكم بين الشعراء في عكاظ.', 'UGC NET Arabic', 'الوحدة ٤ · النقد العربي', 'easy');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100092, 'mcq', 'قال لـ المتلمس: «استنوق الجمل»، وهو:', '["عنترة", "طرفة بن العبد", "النابغة الذبياني", "لبيد"]', '[1]', 'عبارة نقدية مشهورة في النقد الجاهلي.', 'UGC NET Arabic', 'الوحدة ٤ · النقد العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100093, 'mcq', 'من أشهر النقاد في العصر الإسلامي، إلى جانب ابن عتيق:', '["رابعة العدوية", "ولادة بنت المستكفي", "الخنساء", "سكينة بنت الحسين"]', '[3]', 'اشتهرت سكينة بنت الحسين بمجالس النقد الأدبي.', 'UGC NET Arabic', 'الوحدة ٤ · النقد العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100094, 'mcq', '«طبقات فحول الشعراء» من تأليف:', '["قدامة بن جعفر", "ابن سلام الجمحي", "ابن قتيبة", "الآمدي"]', '[1]', 'هو أقدم ما وصل إلينا من كتب الطبقات.', 'UGC NET Arabic', 'الوحدة ٤ · النقد العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100095, 'mcq', 'كتاب «الشعر والشعراء» أول تراجم الشعراء، وهو لـ:', '["ابن رشيق", "الجاحظ", "ابن قتيبة", "المبرد"]', '[2]', 'ألفه ابن قتيبة الدينوري.', 'UGC NET Arabic', 'الوحدة ٤ · النقد العربي', 'easy');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100096, 'mcq', 'نُسب ابن قتيبة إلى «الدينور» لأنه:', '["تولى القضاء فيها", "دفن فيها", "ولد فيها", "درّس فيها"]', '[0]', 'كان قاضيًا في مدينة الدينور بفارس.', 'UGC NET Arabic', 'الوحدة ٤ · النقد العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100097, 'mcq', '«نقد الشعر» الذي قيل إنه أول كتاب مستقل في النقد هو لـ:', '["الجرجاني", "الآمدي", "ابن طباطبا", "قدامة بن جعفر"]', '[3]', 'كتاب «نقد الشعر» لقدامة بن جعفر البغدادي.', 'UGC NET Arabic', 'الوحدة ٤ · النقد العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100098, 'mcq', '«العمدة في محاسن الشعر وآدابه» لـ:', '["ابن قتيبة", "ابن رشيق القيرواني", "الجاحظ", "ابن سلام"]', '[1]', 'أثنى ابن خلدون على العمدة لانفراده بهذه الصنعة.', 'UGC NET Arabic', 'الوحدة ٤ · النقد العربي', 'easy');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100099, 'mcq', '«الموازنة بين أبي تمام والبحتري» من تأليف:', '["ابن الأثير", "الجرجاني", "المرزباني", "الآمدي"]', '[3]', 'كتاب موازنة بين شاعرين.', 'UGC NET Arabic', 'الوحدة ٤ · النقد العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100100, 'mcq', 'واضع علم البلاغة ومؤسس علم البيان هو:', '["عبد القاهر الجرجاني", "الجاحظ", "السكاكي", "ابن المعتز"]', '[0]', 'له «أسرار البلاغة» و«دلائل الإعجاز».', 'UGC NET Arabic', 'الوحدة ٤ · النقد العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100101, 'mcq', 'القائل: «الألفاظ خدم المعاني» في الكتاب هو:', '["ابن قتيبة", "عبد القاهر الجرجاني", "قدامة بن جعفر", "الآمدي"]', '[1]', 'مبدأ نقدي معروف عنده.', 'UGC NET Arabic', 'الوحدة ٤ · النقد العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100102, 'mcq', 'اللقب الذي عُرف به طه حسين هو:', '["أمير الشعراء", "رائد القصة", "شاعر النيل", "عميد الأدب العربي"]', '[3]', 'لقبه أيضًا: الدكتور والباشا.', 'UGC NET Arabic', 'الوحدة ٤ · النقد العربي', 'easy');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100103, 'mcq', 'كتاب طه حسين الأول في الأدب هو:', '["في الشعر الجاهلي", "تجديد ذكرى أبي العلاء", "مع أبي العلاء في سجنه", "الأيام"]', '[1]', 'أول ترجمة عصرية لأبي العلاء المعري.', 'UGC NET Arabic', 'الوحدة ٤ · النقد العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100104, 'mcq', '«القصر المسحور» كتبه طه حسين بالاشتراك مع:', '["العقاد", "نجيب محفوظ", "توفيق الحكيم", "المنفلوطي"]', '[2]', 'عمل أدبي مشترك بين الأديبين.', 'UGC NET Arabic', 'الوحدة ٤ · النقد العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100105, 'mcq', 'وُلد عباس محمود العقاد في:', '["الإسكندرية", "طنطا", "القاهرة", "أسوان"]', '[3]', 'ولد العقاد في أسوان.', 'UGC NET Arabic', 'الوحدة ٤ · النقد العربي', 'easy');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100106, 'mcq', 'آخر دواوين العقاد هو:', '["وهج الظهيرة", "أشباح الأصيل", "يقظة الصباح", "بعد الأعاصير"]', '[3]', 'أول دواوينه «يقظة الصباح» وآخرها «بعد الأعاصير».', 'UGC NET Arabic', 'الوحدة ٤ · النقد العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100107, 'mcq', 'من مؤسسي مدرسة الديوان مع العقاد:', '["شوقي وحافظ", "المازني وعبد الرحمن شكري", "جبران ونعيمة", "مطران والرصافي"]', '[1]', 'مدرسة الديوان: العقاد والمازني وشكري.', 'UGC NET Arabic', 'الوحدة ٤ · النقد العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100108, 'mcq', '«النقد المنهجي عند العرب» من تأليف:', '["أحمد الشايب", "غنيمي هلال", "شوقي ضيف", "محمد مندور"]', '[3]', 'ولد مندور في كفر مندور بالشرقية.', 'UGC NET Arabic', 'الوحدة ٤ · النقد العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100109, 'mcq', '«النقد الأدبي الحديث» من مؤلفات:', '["طه حسين", "غنيمي هلال", "محمد مندور", "أحمد أمين"]', '[1]', 'ولد غنيمي هلال في سلامنت بالشرقية.', 'UGC NET Arabic', 'الوحدة ٤ · النقد العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100110, 'mcq', '«أصول النقد الأدبي» من تأليف:', '["حسين المرصفي", "أحمد الشايب", "العقاد", "شوقي ضيف"]', '[1]', 'ولد الشايب في شبرا بخوم (المنوفية).', 'UGC NET Arabic', 'الوحدة ٤ · النقد العربي', 'medium');
INSERT OR IGNORE INTO quizzes (id, title, description, instructions, subject, topic, difficulty, status, mode, duration_minutes, attempt_limit, pass_mark, marks_per_question, negative_marks, shuffle_questions, shuffle_options, show_answers, access_type, published_at) VALUES (1007, 'الوحدة ٤ — اختيار من متعدد', 'النقد العربي', 'اقرأ كل سؤال بعناية ثم اختر إجابة واحدة صحيحة. لكل سؤال درجتان ولا خصم على الإجابة الخاطئة.', 'UGC NET Arabic', 'النقد العربي', 'medium', 'published', 'both', 20, 0, 40, 2, 0, 0, 0, 1, 'free', datetime('now'));
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1007, 100091, 0);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1007, 100092, 1);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1007, 100093, 2);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1007, 100094, 3);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1007, 100095, 4);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1007, 100096, 5);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1007, 100097, 6);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1007, 100098, 7);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1007, 100099, 8);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1007, 100100, 9);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1007, 100101, 10);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1007, 100102, 11);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1007, 100103, 12);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1007, 100104, 13);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1007, 100105, 14);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1007, 100106, 15);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1007, 100107, 16);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1007, 100108, 17);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1007, 100109, 18);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1007, 100110, 19);

INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100111, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - كانت للنابغة الذبياني قبة حمراء في عكاظ
2 - قال طرفة للمتلمس: «استنوق الجمل»
3 - ابن عتيق وسكينة بنت الحسين من نقاد العصر العباسي', '["العبارتان 2 و 3 فقط صحيحتان", "العبارتان 1 و 2 فقط صحيحتان", "العبارة 1 فقط صحيحة", "العبارة 3 فقط صحيحة"]', '[1]', 'هما من نقاد العصر الإسلامي.', 'UGC NET Arabic', 'الوحدة ٤ · النقد العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100112, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - «طبقات فحول الشعراء» لابن قتيبة
2 - «الشعر والشعراء» أول تراجم الشعراء
3 - لُقّب ابن قتيبة بالدينوري', '["العبارتان 2 و 3 فقط صحيحتان", "العبارة 2 فقط صحيحة", "العبارات 1 و 2 و 3 جميعها صحيحة", "العبارتان 1 و 2 فقط صحيحتان"]', '[0]', '«الطبقات» لابن سلام الجمحي.', 'UGC NET Arabic', 'الوحدة ٤ · النقد العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100113, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - «نقد الشعر» لقدامة بن جعفر
2 - «العمدة» لابن رشيق القيرواني
3 - «الموازنة» للآمدي', '["العبارة 2 فقط صحيحة", "العبارتان 1 و 2 فقط صحيحتان", "العبارة 1 فقط صحيحة", "العبارات 1 و 2 و 3 جميعها صحيحة"]', '[3]', 'العبارات الثلاث صحيحة.', 'UGC NET Arabic', 'الوحدة ٤ · النقد العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100114, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - عبد القاهر الجرجاني واضع علم البلاغة ومؤسس علم البيان
2 - ابن رشيق القيرواني ناقد مصري
3 - قال ابن خلدون: انفرد كتاب «العمدة» بهذه الصنعة وأعطاها حقها', '["العبارتان 2 و 3 فقط صحيحتان", "العبارة 1 فقط صحيحة", "العبارة 3 فقط صحيحة", "العبارتان 1 و 3 فقط صحيحتان"]', '[3]', 'ابن رشيق قيرواني من إفريقية؛ فالعبارة 2 خاطئة.', 'UGC NET Arabic', 'الوحدة ٤ · النقد العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100115, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - لقب طه حسين «أمير الشعراء»
2 - «تجديد ذكرى أبي العلاء» كتابه الأول في الأدب
3 - وُلد طه حسين في أسوان', '["العبارة 1 فقط صحيحة", "العبارة 3 فقط صحيحة", "العبارتان 2 و 3 فقط صحيحتان", "العبارة 2 فقط صحيحة"]', '[3]', 'لقبه عميد الأدب العربي، ومولده في مغاغة بمصر.', 'UGC NET Arabic', 'الوحدة ٤ · النقد العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100116, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - اختير طه حسين وزيرًا للتعليم في عهد النحاس باشا
2 - كتب «القصر المسحور» مع نجيب محفوظ
3 - لم يشكّ طه حسين في وجود امرئ القيس', '["العبارة 3 فقط صحيحة", "العبارة 2 فقط صحيحة", "العبارتان 1 و 3 فقط صحيحتان", "العبارة 1 فقط صحيحة"]', '[3]', 'شارك فيه توفيق الحكيم، وقد شكّ في وجود امرئ القيس.', 'UGC NET Arabic', 'الوحدة ٤ · النقد العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100117, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - وُلد العقاد في الإسكندرية
2 - أول دواوين العقاد «بعد الأعاصير»
3 - من مدرسة الديوان العقاد والمازني وشكري', '["العبارة 2 فقط صحيحة", "العبارة 1 فقط صحيحة", "العبارة 3 فقط صحيحة", "العبارتان 1 و 3 فقط صحيحتان"]', '[2]', 'مولد العقاد في أسوان، وأول دواوينه «يقظة الصباح».', 'UGC NET Arabic', 'الوحدة ٤ · النقد العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100118, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - وُلد أحمد الشايب في شبرا بخوم بالمنوفية
2 - ألّف الشايب «أصول النقد الأدبي»
3 - الشايب صاحب «النقد المنهجي عند العرب»', '["العبارتان 1 و 3 فقط صحيحتان", "العبارات 1 و 2 و 3 جميعها صحيحة", "العبارتان 1 و 2 فقط صحيحتان", "العبارة 2 فقط صحيحة"]', '[2]', '«النقد المنهجي» لمحمد مندور.', 'UGC NET Arabic', 'الوحدة ٤ · النقد العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100119, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - وُلد محمد مندور في الإسكندرية
2 - أُرسل مندور إلى باريس للحصول على الليسانس
3 - من كتبه «النقد المنهجي عند العرب»', '["العبارة 1 فقط صحيحة", "العبارتان 2 و 3 فقط صحيحتان", "العبارات 1 و 2 و 3 جميعها صحيحة", "العبارتان 1 و 2 فقط صحيحتان"]', '[1]', 'وُلد مندور في كفر مندور بالشرقية.', 'UGC NET Arabic', 'الوحدة ٤ · النقد العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100120, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - وُلد شوقي ضيف في أولاد حمام بدمياط
2 - «الفن ومذاهبه في الشعر العربي» لغنيمي هلال
3 - عبد السلام المسدي أكاديمي تونسي ووزير', '["العبارتان 1 و 3 فقط صحيحتان", "العبارة 1 فقط صحيحة", "العبارات 1 و 2 و 3 جميعها صحيحة", "العبارة 3 فقط صحيحة"]', '[0]', 'الكتاب لشوقي ضيف؛ فالعبارة 2 خاطئة.', 'UGC NET Arabic', 'الوحدة ٤ · النقد العربي', 'medium');
INSERT OR IGNORE INTO quizzes (id, title, description, instructions, subject, topic, difficulty, status, mode, duration_minutes, attempt_limit, pass_mark, marks_per_question, negative_marks, shuffle_questions, shuffle_options, show_answers, access_type, published_at) VALUES (1008, 'الوحدة ٤ — أسئلة العبارات', 'النقد العربي', 'اقرأ العبارات في كل سؤال، ثم اختر الخيار الذي يحدد العبارات الصحيحة. لكل سؤال درجتان ولا خصم على الإجابة الخاطئة.', 'UGC NET Arabic', 'النقد العربي', 'medium', 'published', 'both', 15, 0, 40, 2, 0, 0, 0, 1, 'free', datetime('now'));
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1008, 100111, 0);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1008, 100112, 1);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1008, 100113, 2);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1008, 100114, 3);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1008, 100115, 4);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1008, 100116, 5);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1008, 100117, 6);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1008, 100118, 7);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1008, 100119, 8);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1008, 100120, 9);

INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100121, 'mcq', 'كتاب «الأغاني» من تأليف:', '["المبرد", "أبي الفرج الأصفهاني", "ابن عبد ربه", "الجاحظ"]', '[1]', '«الأغاني» أول كتاب مختص في فن الغناء في العربية، ويُعدّ مرجعًا في الأدب.', 'UGC NET Arabic', 'الوحدة ٥ · أمهات الكتب في التراث العربي', 'easy');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100122, 'mcq', 'يُنسب أبو الفرج الأصفهاني إلى:', '["عبد الملك بن مروان", "المعتصم", "مروان بن محمد آخر خلفاء الأمويين", "هارون الرشيد"]', '[2]', 'ولد بأصفهان ونشأ ببغداد.', 'UGC NET Arabic', 'الوحدة ٥ · أمهات الكتب في التراث العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100123, 'mcq', 'صدّر صاحب «الأغاني» كتابه بالأصوات المئة التي اختارها:', '["أبو نواس بأمر الأمين", "الأصمعي بأمر المأمون", "إبراهيم الموصلي ومغنّوه بأمر هارون الرشيد", "إسحاق الكندي بأمر المعتصم"]', '[2]', 'اختيرت الأصوات المئة في عهد الرشيد.', 'UGC NET Arabic', 'الوحدة ٥ · أمهات الكتب في التراث العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100124, 'mcq', 'كتاب «البيان والتبيين» من تأليف:', '["الجاحظ", "ابن قتيبة", "ابن جني", "المبرد"]', '[0]', 'تحدث في جزئه الأول عن مفهوم البيان وأنواعه وآفات اللسان والبلاغة والفصاحة.', 'UGC NET Arabic', 'الوحدة ٥ · أمهات الكتب في التراث العربي', 'easy');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100125, 'mcq', 'يُعدّ مؤسس علم الاجتماع الحديث:', '["ابن حزم", "الفارابي", "ابن خلدون", "الجاحظ"]', '[2]', '«المقدمة» هي مدخل كتاب «العبر» لابن خلدون.', 'UGC NET Arabic', 'الوحدة ٥ · أمهات الكتب في التراث العربي', 'easy');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100126, 'mcq', 'يُعرف كتاب «العبر» لابن خلدون أيضًا بـ:', '["تاريخ ابن خلدون", "نهج البلاغة", "كشف الظنون", "مروج الذهب"]', '[0]', 'عُرف الكتاب بتاريخ ابن خلدون.', 'UGC NET Arabic', 'الوحدة ٥ · أمهات الكتب في التراث العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100127, 'mcq', 'وُلد ابن عبد ربه صاحب «العقد الفريد» في:', '["بلنسية", "غرناطة", "قرطبة", "إشبيلية"]', '[2]', 'ونشأ فيها.', 'UGC NET Arabic', 'الوحدة ٥ · أمهات الكتب في التراث العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100128, 'mcq', 'سُمّيت أبواب «العقد الفريد» بأسماء:', '["الكواكب", "الجواهر والأحجار الكريمة", "الأنهار", "أسماء الشعراء"]', '[1]', 'مثل المرجانة والجمانة والجوهرة.', 'UGC NET Arabic', 'الوحدة ٥ · أمهات الكتب في التراث العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100129, 'mcq', '«الكامل في اللغة والأدب» من تأليف:', '["ابن جني", "ثعلب", "المبرد", "السيوطي"]', '[2]', 'عدّه العلماء أصلًا من أصول علم الأدب.', 'UGC NET Arabic', 'الوحدة ٥ · أمهات الكتب في التراث العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100130, 'mcq', 'يُعدّ المبرد ممثلًا لمذهب:', '["الأندلس في النحو", "الكوفة في النحو", "البصرة في النحو", "بغداد في النحو"]', '[2]', 'قال حنا الفاخوري: كان ممثلًا لمذهب البصرة وثعلب ممثلًا لمذهب الكوفة.', 'UGC NET Arabic', 'الوحدة ٥ · أمهات الكتب في التراث العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100131, 'mcq', '«الفهرست» من تأليف:', '["ابن النديم", "ياقوت الحموي", "ابن خلكان", "حاجي خليفة"]', '[0]', 'جمع فيه ما صدر من الكتب والمقالات العربية في زمنه.', 'UGC NET Arabic', 'الوحدة ٥ · أمهات الكتب في التراث العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100132, 'mcq', '«إرشاد الأريب إلى معرفة الأديب» اسم آخر لكتاب:', '["معجم الأدباء", "الفهرست", "كشف الظنون", "وفيات الأعيان"]', '[0]', '«معجم الأدباء» لياقوت الحموي.', 'UGC NET Arabic', 'الوحدة ٥ · أمهات الكتب في التراث العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100133, 'mcq', 'كتاب «الخصائص» من تأليف:', '["المبرد", "ابن جني", "السيوطي", "البلاذري"]', '[1]', 'من أشهر ما كتب في فقه اللغة وفلسفتها وأسرار العربية.', 'UGC NET Arabic', 'الوحدة ٥ · أمهات الكتب في التراث العربي', 'easy');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100134, 'mcq', 'يُعدّ ابن جني أول من شرح ديوان:', '["امرئ القيس", "المتنبي", "البحتري", "أبي تمام"]', '[1]', 'له الشرح الصغير والشرح الكبير.', 'UGC NET Arabic', 'الوحدة ٥ · أمهات الكتب في التراث العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100135, 'mcq', '«المزهر في علوم اللغة وأنواعها» من تأليف:', '["ابن فارس", "ابن جني", "المبرد", "السيوطي"]', '[3]', 'يضم خمسين نوعًا من علوم اللغة.', 'UGC NET Arabic', 'الوحدة ٥ · أمهات الكتب في التراث العربي', 'easy');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100136, 'mcq', '«كشف الظنون عن أسامي الكتب والفنون» لـ:', '["ابن خلكان", "ياقوت الحموي", "حاجي خليفة (كاتب جلبي)", "ابن النديم"]', '[2]', 'دائرة معارف وسجل عام في تواريخ المصنفات.', 'UGC NET Arabic', 'الوحدة ٥ · أمهات الكتب في التراث العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100137, 'mcq', '«مروج الذهب ومعادن الجوهر» من تأليف:', '["المسعودي", "البلاذري", "ابن خلكان", "الطبري"]', '[0]', 'اختصره من كتابه «الأوسط».', 'UGC NET Arabic', 'الوحدة ٥ · أمهات الكتب في التراث العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100138, 'mcq', '«وفيات الأعيان وأنباء أبناء الزمان» من تأليف:', '["الذهبي", "ابن النديم", "ياقوت الحموي", "ابن خلكان"]', '[3]', 'وُلد في إربل وتوفي في دمشق.', 'UGC NET Arabic', 'الوحدة ٥ · أمهات الكتب في التراث العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100139, 'mcq', 'استقدم الحكم (ابن الخليفة) إلى قرطبة صاحب كتاب «الأمالي»:', '["أبا علي القالي", "ثعلب", "المبرد", "ابن جني"]', '[0]', 'ينقسم كتاب الأمالي إلى الأمالي والذيل والنوادر.', 'UGC NET Arabic', 'الوحدة ٥ · أمهات الكتب في التراث العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100140, 'mcq', '«فجر الإسلام» من تأليف:', '["أحمد أمين", "طه حسين", "العقاد", "شوقي ضيف"]', '[0]', 'ثم «ضحى الإسلام» و«ظهر الإسلام».', 'UGC NET Arabic', 'الوحدة ٥ · أمهات الكتب في التراث العربي', 'easy');
INSERT OR IGNORE INTO quizzes (id, title, description, instructions, subject, topic, difficulty, status, mode, duration_minutes, attempt_limit, pass_mark, marks_per_question, negative_marks, shuffle_questions, shuffle_options, show_answers, access_type, published_at) VALUES (1009, 'الوحدة ٥ — اختيار من متعدد', 'أمهات الكتب في التراث العربي', 'اقرأ كل سؤال بعناية ثم اختر إجابة واحدة صحيحة. لكل سؤال درجتان ولا خصم على الإجابة الخاطئة.', 'UGC NET Arabic', 'أمهات الكتب في التراث العربي', 'medium', 'published', 'both', 20, 0, 40, 2, 0, 0, 0, 1, 'free', datetime('now'));
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1009, 100121, 0);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1009, 100122, 1);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1009, 100123, 2);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1009, 100124, 3);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1009, 100125, 4);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1009, 100126, 5);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1009, 100127, 6);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1009, 100128, 7);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1009, 100129, 8);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1009, 100130, 9);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1009, 100131, 10);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1009, 100132, 11);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1009, 100133, 12);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1009, 100134, 13);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1009, 100135, 14);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1009, 100136, 15);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1009, 100137, 16);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1009, 100138, 17);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1009, 100139, 18);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1009, 100140, 19);

INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100141, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - يُنسب مؤلف «الأغاني» إلى مروان بن محمد آخر خلفاء الأمويين
2 - وُلد أبو الفرج الأصفهاني بأصفهان ونشأ ببغداد
3 - مؤلف «الأغاني» هو الجاحظ', '["العبارة 2 فقط صحيحة", "العبارتان 1 و 2 فقط صحيحتان", "العبارتان 1 و 3 فقط صحيحتان", "العبارات 1 و 2 و 3 جميعها صحيحة"]', '[1]', '«الأغاني» لأبي الفرج الأصفهاني.', 'UGC NET Arabic', 'الوحدة ٥ · أمهات الكتب في التراث العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100142, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - «البيان والتبيين» لابن قتيبة
2 - تحدّث الجزء الأول عن مفهوم البيان وأنواعه وآفات اللسان
3 - ابن خلدون مؤسس علم الاجتماع الحديث', '["العبارات 1 و 2 و 3 جميعها صحيحة", "العبارتان 2 و 3 فقط صحيحتان", "العبارتان 1 و 3 فقط صحيحتان", "العبارتان 1 و 2 فقط صحيحتان"]', '[1]', '«البيان والتبيين» للجاحظ.', 'UGC NET Arabic', 'الوحدة ٥ · أمهات الكتب في التراث العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100143, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - بدأ ابن خلدون كتابة «المقدمة» في قلعة ابن سلامة
2 - وُلد ابن خلدون في الأندلس
3 - يُعرف كتاب «العبر» بتاريخ ابن خلدون', '["العبارتان 1 و 2 فقط صحيحتان", "العبارتان 2 و 3 فقط صحيحتان", "العبارة 2 فقط صحيحة", "العبارتان 1 و 3 فقط صحيحتان"]', '[3]', 'وُلد ابن خلدون في تونس؛ فالعبارة 2 خاطئة.', 'UGC NET Arabic', 'الوحدة ٥ · أمهات الكتب في التراث العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100144, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - وُلد ابن عبد ربه في قرطبة
2 - سُمّيت أبواب «العقد الفريد» بأسماء الجواهر
3 - «العقد الفريد» على نسق «عيون الأخبار» لابن قتيبة', '["العبارتان 2 و 3 فقط صحيحتان", "العبارات 1 و 2 و 3 جميعها صحيحة", "العبارتان 1 و 2 فقط صحيحتان", "العبارة 1 فقط صحيحة"]', '[1]', 'العبارات الثلاث صحيحة.', 'UGC NET Arabic', 'الوحدة ٥ · أمهات الكتب في التراث العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100145, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - «الكامل» لابن الأثير
2 - أخذ المبرد العلم عن الجرمي والمازني
3 - المبرد ممثل مذهب الكوفة', '["العبارة 2 فقط صحيحة", "العبارتان 1 و 3 فقط صحيحتان", "العبارات 1 و 2 و 3 جميعها صحيحة", "العبارة 3 فقط صحيحة"]', '[0]', '«الكامل» للمبرد وهو بصري المذهب؛ فالعبارة 2 فقط صحيحة.', 'UGC NET Arabic', 'الوحدة ٥ · أمهات الكتب في التراث العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100146, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - «الفهرست» لابن النديم
2 - أول كتاب في آداب اللغة العربية «معجم الأدباء»
3 - «معجم الأدباء» لابن النديم', '["العبارة 3 فقط صحيحة", "العبارة 1 فقط صحيحة", "العبارة 2 فقط صحيحة", "العبارتان 1 و 3 فقط صحيحتان"]', '[1]', '«معجم الأدباء» لياقوت الحموي؛ فالعبارة 1 فقط صحيحة.', 'UGC NET Arabic', 'الوحدة ٥ · أمهات الكتب في التراث العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100147, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - «الخصائص» للسيوطي
2 - أول من شرح ديوان المتنبي البلاذري
3 - ابن جني أول من شرح ديوان المتنبي', '["العبارتان 1 و 3 فقط صحيحتان", "العبارة 2 فقط صحيحة", "العبارة 3 فقط صحيحة", "العبارات 1 و 2 و 3 جميعها صحيحة"]', '[2]', '«الخصائص» لابن جني؛ فالعبارة 3 فقط صحيحة.', 'UGC NET Arabic', 'الوحدة ٥ · أمهات الكتب في التراث العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100148, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - «المزهر» للسيوطي
2 - «كشف الظنون» لحاجي خليفة
3 - «مروج الذهب» لابن خلكان', '["العبارات 1 و 2 و 3 جميعها صحيحة", "العبارتان 2 و 3 فقط صحيحتان", "العبارتان 1 و 2 فقط صحيحتان", "العبارة 3 فقط صحيحة"]', '[2]', '«مروج الذهب» للمسعودي.', 'UGC NET Arabic', 'الوحدة ٥ · أمهات الكتب في التراث العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100149, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - وُلد ابن خلكان في دمشق وتوفي في إربل
2 - من كتب البلاذري «فتوح البلدان»
3 - من كتب البلاذري «أنساب الأشراف»', '["العبارتان 2 و 3 فقط صحيحتان", "العبارتان 1 و 2 فقط صحيحتان", "العبارات 1 و 2 و 3 جميعها صحيحة", "العبارتان 1 و 3 فقط صحيحتان"]', '[0]', 'وُلد ابن خلكان في إربل وتوفي في دمشق؛ فالعبارة 1 خاطئة.', 'UGC NET Arabic', 'الوحدة ٥ · أمهات الكتب في التراث العربي', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100150, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - «فجر الإسلام» لأحمد أمين
2 - يبحث «ضحى الإسلام» في صدر الإسلام إلى آخر الدولة الأموية
3 - وُلد أحمد أمين في حي المنشية بالقاهرة', '["العبارة 1 فقط صحيحة", "العبارات 1 و 2 و 3 جميعها صحيحة", "العبارتان 1 و 3 فقط صحيحتان", "العبارتان 1 و 2 فقط صحيحتان"]', '[2]', 'هذا موضوع «فجر الإسلام»؛ فالعبارة 2 خاطئة.', 'UGC NET Arabic', 'الوحدة ٥ · أمهات الكتب في التراث العربي', 'medium');
INSERT OR IGNORE INTO quizzes (id, title, description, instructions, subject, topic, difficulty, status, mode, duration_minutes, attempt_limit, pass_mark, marks_per_question, negative_marks, shuffle_questions, shuffle_options, show_answers, access_type, published_at) VALUES (1010, 'الوحدة ٥ — أسئلة العبارات', 'أمهات الكتب في التراث العربي', 'اقرأ العبارات في كل سؤال، ثم اختر الخيار الذي يحدد العبارات الصحيحة. لكل سؤال درجتان ولا خصم على الإجابة الخاطئة.', 'UGC NET Arabic', 'أمهات الكتب في التراث العربي', 'medium', 'published', 'both', 15, 0, 40, 2, 0, 0, 0, 1, 'free', datetime('now'));
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1010, 100141, 0);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1010, 100142, 1);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1010, 100143, 2);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1010, 100144, 3);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1010, 100145, 4);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1010, 100146, 5);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1010, 100147, 6);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1010, 100148, 7);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1010, 100149, 8);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1010, 100150, 9);

INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100151, 'mcq', 'رائد مدرسة البعث والإحياء ورائد الشعر العربي الحديث هو:', '["خليل مطران", "محمود سامي البارودي", "حافظ إبراهيم", "أحمد شوقي"]', '[1]', 'البارودي رائد الشعر الكلاسيكي الحديث.', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'easy');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100152, 'mcq', 'دُفن محمود سامي البارودي في مقبرة:', '["الإمام الشافعي", "السيدة نفيسة", "البقيع", "الإمام الحسين"]', '[0]', 'توفي في القاهرة ودُفن في مقبرة الإمام الشافعي.', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100153, 'mcq', 'قال: «إن الشعر لمعة خيالية يتألق وميضها في سماوة الفكر» في مقدمة ديوانه:', '["البارودي", "مطران", "حافظ إبراهيم", "أحمد شوقي"]', '[0]', 'تعريفه للشعر في مقدمة ديوانه.', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100154, 'mcq', 'يُلقب بـ«شاعر النيل» و«شاعر الشعب»:', '["البارودي", "حافظ إبراهيم", "أحمد شوقي", "معروف الرصافي"]', '[1]', 'لُقّب أيضًا بشاعر المجتمع والسياسة والحدث.', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'easy');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100155, 'mcq', 'وُلد حافظ إبراهيم على متن:', '["قطار", "سفينة على النيل", "خيمة في الصحراء", "قصر في القاهرة"]', '[1]', 'وُلد في سفينة (ذهبية) راسية على النيل.', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100156, 'mcq', 'يُلقب خليل مطران بـ:', '["شاعر القطرين", "شاعر الجنان", "أمير الشعراء", "شاعر النيل"]', '[0]', 'القطران: لبنان ومصر.', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'easy');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100157, 'mcq', 'عمل خليل مطران في مصر محررًا لجريدة:', '["المقطم", "الأخبار", "المؤيد", "الأهرام"]', '[3]', 'هاجر من لبنان إلى باريس ثم إلى مصر.', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100158, 'mcq', 'يُلقب أحمد شوقي بـ:', '["شاعر القطرين", "عميد الأدب", "أمير الشعراء", "شاعر الشعب"]', '[2]', 'ورائد الشعر المسرحي.', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'easy');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100159, 'mcq', 'أول رئيس لجمعية أبولو هو:', '["أحمد زكي أبو شادي", "حافظ إبراهيم", "أحمد شوقي", "العقاد"]', '[2]', 'أسندت رئاستها إلى شوقي ولكنه توفي في السنة نفسها.', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100160, 'mcq', 'رائد الحركة المسرحية الشعرية بعد شوقي:', '["علي أحمد باكثير", "سعد الله ونوس", "توفيق الحكيم", "عزيز أباظة"]', '[3]', 'له مسرحيات شعرية وديوان صدر بعد وفاته.', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100161, 'mcq', '«رائد الشعراء العراقيين وشاعر البؤساء» هو:', '["الجواهري", "معروف الرصافي", "نازك الملائكة", "بدر شاكر السياب"]', '[1]', 'ويلقب بشاعر القصص والحكمة والوصف.', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100162, 'mcq', 'أول دواوين معروف الرصافي هو:', '["الجداول", "الأيوبيات", "الشوقيات", "الرصافيات"]', '[3]', 'سُمّي ديوانه الأول بالرصافيات.', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100163, 'mcq', 'يُلقب أبو القاسم الشابي بـ:', '["شاعر الحب والحياة (شاعر الخضراء)", "شاعر المقاومة", "شاعر الخمر", "شاعر الحكمة"]', '[0]', 'شاعر تونسي نشر شقيقه ديوانه بعد موته.', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100164, 'mcq', 'أحد مؤسسي الشعر الحر (شعر التفعيلة) هو:', '["الأخطل الصغير", "عمر أبو ريشة", "أحمد شوقي", "بدر شاكر السياب"]', '[3]', 'ويُعرف بقصيدة «أنشودة المطر».', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100165, 'mcq', 'أطلق مارون عبود على نازك الملائكة لقب:', '["خنساء القرن العشرين", "شاعرة النيل", "أمّ الشعر", "أميرة الشعراء"]', '[0]', 'نازك شاعرة عراقية رائدة في الشعر الحر.', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100166, 'mcq', 'أول دواوين نازك الملائكة هو:', '["شظايا ورماد", "عاشقة الليل", "قرارة الموجة", "أنا وحيدة"]', '[1]', 'نُشر أولًا بعنوان «عاشقة الليل».', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100167, 'mcq', 'سُمّي الشاعر عمر أبو ريشة عمر تيمنًا بـ:', '["عمر بن أبي ربيعة", "عمر بن عبد العزيز", "عمر الخيام", "عمر بن الخطاب"]', '[0]', 'هو شاعر سوري ألحق بالسلك الدبلوماسي.', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100168, 'mcq', '«عصفور الشرق»، شاعر الحب والمرأة السوري هو:', '["محمود درويش", "نزار قباني", "أدونيس", "أمل دنقل"]', '[1]', 'اشتهر بأشعار الغزل ثم السياسة بعد النكسة.', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'easy');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100169, 'mcq', 'قصيدة «هوامش على دفتر النكسة» لـ:', '["محمود درويش", "نزار قباني", "فدوى طوقان", "أدونيس"]', '[1]', 'قالها بعد نكسة حزيران.', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100170, 'mcq', 'ديوان «وحدي مع الأيام» لـ:', '["فدوى طوقان", "ليلى العثمان", "أحلام مستغانمي", "نازك الملائكة"]', '[0]', 'ولدت في نابلس ولقبت بشاعرة فلسطين.', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100171, 'mcq', '«عابرون في كلام عابر» لـ:', '["محمود درويش", "أدونيس", "فدوى طوقان", "سميح القاسم"]', '[0]', 'وُلد درويش في فلسطين ودُفن في رام الله.', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100172, 'mcq', 'أول من نادى بتحرير المرأة من ربقة الجهل في العصر الحديث:', '["رفاعة الطهطاوي", "محمد عبده", "المنفلوطي", "قاسم أمين"]', '[0]', 'وُلد في طهطا بسوهاج.', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100173, 'mcq', 'يُعدّ رائدًا لتحرير النثر العربي من قيود السجع والجناس:', '["المنفلوطي", "الرافعي", "هيكل", "محمد عبده"]', '[0]', 'من كتبه «العبرات» و«النظرات».', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100174, 'mcq', 'مؤسس فن الأقصوصة في الأدب العربي الحديث:', '["زكريا تامر", "يوسف إدريس", "محمود تيمور", "يحيى حقي"]', '[2]', 'وكان أخوه محمد تيمور صاحب أول قصة قصيرة.', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100175, 'mcq', 'أول روايات جرجي زيدان هي:', '["أرمانوسة المصرية", "فتح الأندلس", "الحجاج بن يوسف", "المملوك الشارد"]', '[3]', 'كتب روايات تاريخية كثيرة.', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100176, 'mcq', 'يُلقب بـ«عميد الرواية العربية» و«أمير الرواية»:', '["توفيق الحكيم", "يوسف إدريس", "نجيب محفوظ", "إحسان عبد القدوس"]', '[2]', 'ومن أعماله الثلاثية.', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'easy');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100177, 'mcq', 'أول مجموعة قصصية لنجيب محفوظ:', '["تحت المظلة", "دنيا الله", "خمارة القط الأسود", "همس الجنون"]', '[3]', 'نشر قصصه القصيرة في مجلة الرسالة.', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100178, 'mcq', 'رواية «ذاكرة الجسد» لـ:', '["ليلى العثمان", "غادة السمان", "أحلام منصور", "أحلام مستغانمي"]', '[3]', 'جزائرية نالت جائزة نجيب محفوظ.', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100179, 'mcq', 'يُلقب بـ«أبي المسرح العربي»:', '["أحمد شوقي", "مارون النقاش", "يعقوب صنوع", "توفيق الحكيم"]', '[1]', 'وُلد في صيدا بلبنان.', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100180, 'mcq', 'قال طه حسين: «يفتح بابًا جديدًا في الأدب هو باب الأدب المسرحي»، عن:', '["سعد الله ونوس", "توفيق الحكيم", "أحمد شوقي", "عزيز أباظة"]', '[1]', 'من مسرحياته «شهرزاد» و«سلطان الظلام».', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'easy');
INSERT OR IGNORE INTO quizzes (id, title, description, instructions, subject, topic, difficulty, status, mode, duration_minutes, attempt_limit, pass_mark, marks_per_question, negative_marks, shuffle_questions, shuffle_options, show_answers, access_type, published_at) VALUES (1011, 'الوحدة ٦ — اختيار من متعدد', 'الأدب العربي الحديث', 'اقرأ كل سؤال بعناية ثم اختر إجابة واحدة صحيحة. لكل سؤال درجتان ولا خصم على الإجابة الخاطئة.', 'UGC NET Arabic', 'الأدب العربي الحديث', 'medium', 'published', 'both', 30, 0, 40, 2, 0, 0, 0, 1, 'free', datetime('now'));
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1011, 100151, 0);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1011, 100152, 1);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1011, 100153, 2);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1011, 100154, 3);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1011, 100155, 4);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1011, 100156, 5);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1011, 100157, 6);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1011, 100158, 7);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1011, 100159, 8);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1011, 100160, 9);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1011, 100161, 10);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1011, 100162, 11);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1011, 100163, 12);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1011, 100164, 13);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1011, 100165, 14);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1011, 100166, 15);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1011, 100167, 16);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1011, 100168, 17);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1011, 100169, 18);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1011, 100170, 19);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1011, 100171, 20);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1011, 100172, 21);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1011, 100173, 22);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1011, 100174, 23);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1011, 100175, 24);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1011, 100176, 25);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1011, 100177, 26);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1011, 100178, 27);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1011, 100179, 28);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1011, 100180, 29);

INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100181, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - البارودي رائد مدرسة البعث والإحياء
2 - دُفن البارودي في مقبرة الإمام الشافعي
3 - لُقّب البارودي بشاعر النيل', '["العبارتان 1 و 2 فقط صحيحتان", "العبارتان 1 و 3 فقط صحيحتان", "العبارة 2 فقط صحيحة", "العبارتان 2 و 3 فقط صحيحتان"]', '[0]', 'شاعر النيل هو حافظ إبراهيم.', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100182, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - لُقّب حافظ إبراهيم بأمير الشعراء
2 - وُلد حافظ على متن سفينة على النيل
3 - لُقّب حافظ بشاعر الشعب', '["العبارة 1 فقط صحيحة", "العبارتان 1 و 2 فقط صحيحتان", "العبارة 3 فقط صحيحة", "العبارتان 2 و 3 فقط صحيحتان"]', '[3]', 'أمير الشعراء هو أحمد شوقي.', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100183, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - مطران شاعر القطرين: لبنان ومصر
2 - عمل مطران محررًا لجريدة المقطم
3 - أصدر مطران المجلة المصرية', '["العبارتان 2 و 3 فقط صحيحتان", "العبارتان 1 و 2 فقط صحيحتان", "العبارة 1 فقط صحيحة", "العبارتان 1 و 3 فقط صحيحتان"]', '[3]', 'عمل في الأهرام؛ فالعبارة 2 خاطئة.', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100184, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - أحمد شوقي أول رئيس لجمعية أبولو
2 - عزيز أباظة رائد الحركة المسرحية الشعرية بعد شوقي
3 - من مسرحيات شوقي «مصرع كليوباترا»', '["العبارة 1 فقط صحيحة", "العبارات 1 و 2 و 3 جميعها صحيحة", "العبارة 3 فقط صحيحة", "العبارتان 1 و 2 فقط صحيحتان"]', '[1]', 'العبارات الثلاث صحيحة.', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100185, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - معروف الرصافي شاعر مصري
2 - أول دواوين الرصافي «الرصافيات»
3 - لُقّب الرصافي بأمير الشعراء', '["العبارتان 2 و 3 فقط صحيحتان", "العبارة 2 فقط صحيحة", "العبارتان 1 و 2 فقط صحيحتان", "العبارة 1 فقط صحيحة"]', '[1]', 'الرصافي عراقي، وأمير الشعراء شوقي؛ فالعبارة 2 فقط صحيحة.', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100186, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - الشابي شاعر الحب والحياة والخضراء
2 - وُلد الشابي في العراق
3 - مؤسس مدرسة أبولو أحمد زكي أبو شادي', '["العبارة 1 فقط صحيحة", "العبارتان 1 و 3 فقط صحيحتان", "العبارة 3 فقط صحيحة", "العبارة 2 فقط صحيحة"]', '[1]', 'الشابي تونسي؛ فالعبارة 2 خاطئة.', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100187, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - نازك الملائكة شاعرة مصرية
2 - «أنشودة المطر» أول دواوين نازك
3 - لقّبها مارون عبود بخنساء القرن العشرين', '["العبارة 3 فقط صحيحة", "العبارتان 2 و 3 فقط صحيحتان", "العبارة 1 فقط صحيحة", "العبارات 1 و 2 و 3 جميعها صحيحة"]', '[0]', 'نازك عراقية، و«أنشودة المطر» للسياب؛ فالعبارة 3 فقط صحيحة.', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100188, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - سُمّي عمر أبو ريشة تيمنًا بعمر بن أبي ربيعة
2 - ألحق عمر أبو ريشة بالسلك الدبلوماسي
3 - عمر أبو ريشة شاعر يمني', '["العبارتان 2 و 3 فقط صحيحتان", "العبارة 2 فقط صحيحة", "العبارتان 1 و 2 فقط صحيحتان", "العبارة 3 فقط صحيحة"]', '[2]', 'هو شاعر سوري.', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100189, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - «هوامش على دفتر النكسة» لمحمود درويش
2 - اشتهر درويش بشاعر المقاومة الفلسطينية
3 - توفي درويش في أمريكا ودُفن في رام الله', '["العبارتان 2 و 3 فقط صحيحتان", "العبارة 3 فقط صحيحة", "العبارات 1 و 2 و 3 جميعها صحيحة", "العبارتان 1 و 2 فقط صحيحتان"]', '[0]', 'القصيدة لنزار قباني؛ فالعبارة 1 خاطئة.', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100190, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - وُلد رفاعة الطهطاوي في طهطا
2 - دعا المنفلوطي إلى السجع والجناس
3 - «العبرات» أقاصيص للمنفلوطي', '["العبارتان 2 و 3 فقط صحيحتان", "العبارة 2 فقط صحيحة", "العبارتان 1 و 3 فقط صحيحتان", "العبارة 3 فقط صحيحة"]', '[2]', 'المنفلوطي حرّر النثر من السجع والجناس؛ فالعبارة 2 خاطئة.', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100191, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - مؤسس فن الأقصوصة يحيى حقي
2 - محمد تيمور شقيق محمود تيمور وصاحب أول قصة قصيرة
3 - وُلد جرجي زيدان في القاهرة', '["العبارة 2 فقط صحيحة", "العبارتان 2 و 3 فقط صحيحتان", "العبارتان 1 و 2 فقط صحيحتان", "العبارة 1 فقط صحيحة"]', '[0]', 'مؤسس الأقصوصة محمود تيمور، وزيدان من بيروت؛ فالعبارة 2 فقط صحيحة.', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100192, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - نجيب محفوظ عميد الرواية العربية
2 - أول مجموعة قصصية له «همس الجنون»
3 - «ذاكرة الجسد» لغادة السمان', '["العبارة 2 فقط صحيحة", "العبارة 3 فقط صحيحة", "العبارات 1 و 2 و 3 جميعها صحيحة", "العبارتان 1 و 2 فقط صحيحتان"]', '[3]', '«ذاكرة الجسد» لأحلام مستغانمي.', 'UGC NET Arabic', 'الوحدة ٦ · الأدب العربي الحديث', 'medium');
INSERT OR IGNORE INTO quizzes (id, title, description, instructions, subject, topic, difficulty, status, mode, duration_minutes, attempt_limit, pass_mark, marks_per_question, negative_marks, shuffle_questions, shuffle_options, show_answers, access_type, published_at) VALUES (1012, 'الوحدة ٦ — أسئلة العبارات', 'الأدب العربي الحديث', 'اقرأ العبارات في كل سؤال، ثم اختر الخيار الذي يحدد العبارات الصحيحة. لكل سؤال درجتان ولا خصم على الإجابة الخاطئة.', 'UGC NET Arabic', 'الأدب العربي الحديث', 'medium', 'published', 'both', 18, 0, 40, 2, 0, 0, 0, 1, 'free', datetime('now'));
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1012, 100181, 0);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1012, 100182, 1);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1012, 100183, 2);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1012, 100184, 3);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1012, 100185, 4);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1012, 100186, 5);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1012, 100187, 6);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1012, 100188, 7);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1012, 100189, 8);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1012, 100190, 9);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1012, 100191, 10);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1012, 100192, 11);

INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100193, 'mcq', 'لُقّب بـ«شيخ الإسلام حكيم الأمة»، وهو حنفي أشعري العقيدة:', '["عبد الحي الحسني", "صديق حسن خان القنوجي", "أنور شاه الكشميري", "شاه ولي الله الدهلوي"]', '[3]', 'حفظ القرآن في السابعة من عمره وأخذ العلوم الابتدائية عن والده.', 'UGC NET Arabic', 'الوحدة ٧ · الأدب العربي في الهند', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100194, 'mcq', 'أول من ترجم القرآن إلى الفارسية في الهند، كما ورد في الكتاب:', '["حميد الدين الفراهي", "شاه ولي الله الدهلوي", "أبو الحسن الندوي", "فضل الحق الخيرآبادي"]', '[1]', 'ومن بعده ظهرت أول ترجمة للقرآن بالأردية.', 'UGC NET Arabic', 'الوحدة ٧ · الأدب العربي في الهند', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100195, 'mcq', '«فيوض الحرمين» كتاب في التصوف من مؤلفات:', '["أنور شاه الكشميري", "عبد العزيز الميمني", "صديق حسن خان", "شاه ولي الله الدهلوي"]', '[3]', 'ومن مؤلفاته أيضًا «التفهيمات الإلهية».', 'UGC NET Arabic', 'الوحدة ٧ · الأدب العربي في الهند', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100196, 'mcq', 'نال صديق حسن خان لقب «نواب» بعد زواجه بملكة:', '["بهوبال", "دلهي", "لكناو", "حيدر آباد"]', '[0]', 'تزوج شاهجان بيجوم ملكة بهوبال وأُسندت إليه مهام واسعة.', 'UGC NET Arabic', 'الوحدة ٧ · الأدب العربي في الهند', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100197, 'mcq', '«السراج الوهاج في كشف مطالب صحيح مسلم بن الحجاج» من تأليف:', '["أنور شاه الكشميري", "شاه ولي الله", "عبد الحي الحسني", "صديق حسن خان القنوجي"]', '[3]', 'كتبه ابن بانس بريلي، وله مصنفات كثيرة بالعربية.', 'UGC NET Arabic', 'الوحدة ٧ · الأدب العربي في الهند', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100198, 'mcq', 'لُقّب بـ«ابن خلكان الهند» لكتابه في تراجم العلماء:', '["حميد الدين الفراهي", "أبو محفوظ الكريم المعصومي", "أبو الحسن الندوي", "عبد الحي الحسني"]', '[3]', 'تشبيه بابن خلكان صاحب «وفيات الأعيان».', 'UGC NET Arabic', 'الوحدة ٧ · الأدب العربي في الهند', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100199, 'mcq', '«جمهرة البلاغة» و«وجوه إعجاز القرآن» من مؤلفات:', '["أبو الحسن الندوي", "عبد العزيز الميمني", "حميد الدين الفراهي", "فضل الحق الخيرآبادي"]', '[2]', 'ولد في قرية فيرها من أعظم كره.', 'UGC NET Arabic', 'الوحدة ٧ · الأدب العربي في الهند', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100200, 'mcq', 'توفي عبد العزيز الميمني الراجكوتي في مدينة:', '["لكناو", "كراتشي", "دلهي", "بومباي"]', '[1]', 'ولد في راجكوت ومات في كراتشي.', 'UGC NET Arabic', 'الوحدة ٧ · الأدب العربي في الهند', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100201, 'mcq', '«سمط اللآلي في شرح أمالي القالي» لأبي عبيد البكري، حققه:', '["عبد العزيز الميمني", "أبو الحسن الندوي", "حميد الدين الفراهي", "أنور شاه الكشميري"]', '[0]', 'من تحقيقاته أيضًا «ديوان سحيم عبد بني الحسحاس».', 'UGC NET Arabic', 'الوحدة ٧ · الأدب العربي في الهند', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100202, 'mcq', 'أول كتاب ظهر بالأردية لأبي الحسن الندوي بعنوان:', '["الأركان الأربعة", "سيرة السيد أحمد شهيد", "في مسيرة الحياة", "شخصيات وكتب"]', '[1]', 'وُلد في تكية بمديرية راي بريلي.', 'UGC NET Arabic', 'الوحدة ٧ · الأدب العربي في الهند', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100203, 'mcq', 'كتب أبو الحسن الندوي افتتاحيات مجلة «المسلمون» الصادرة من:', '["بيروت", "دمشق", "الرياض", "القاهرة"]', '[1]', 'وتولّى الكتابة فيها مدة من الزمن.', 'UGC NET Arabic', 'الوحدة ٧ · الأدب العربي في الهند', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100204, 'mcq', 'حفظ القرآن الكريم في أربعة أشهر وله ثلاثة عشر عامًا:', '["أنور شاه الكشميري", "فضل الحق الخيرآبادي", "عبد الحي الحسني", "شاه ولي الله"]', '[1]', 'اعتُقل ونُفي إلى جزيرة أندمان فتوفي فيها.', 'UGC NET Arabic', 'الوحدة ٧ · الأدب العربي في الهند', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100205, 'mcq', 'نُفي إلى جزيرة أندمان النائية حيث توفي:', '["صديق حسن خان", "شاه ولي الله", "فضل الحق الخيرآبادي", "الفراهي"]', '[2]', 'نُفي بعد اعتقاله.', 'UGC NET Arabic', 'الوحدة ٧ · الأدب العربي في الهند', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100206, 'mcq', '«فيض الباري» شرح لصحيح البخاري من تأليف:', '["أنور شاه الكشميري", "صديق حسن خان", "فضل الحق الخيرآبادي", "عبد الحي الحسني"]', '[0]', 'جمع محاضراته التي ألقاها في دار العلوم.', 'UGC NET Arabic', 'الوحدة ٧ · الأدب العربي في الهند', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100207, 'mcq', 'اشتغل أبو الحسن الندوي بالدعوة مع جماعة:', '["أنصار السنة", "الإخوان المسلمين", "التبليغ", "الجماعة الإسلامية"]', '[2]', 'بعد لقائه بالشيخ محمد إلياس مؤسس الجماعة.', 'UGC NET Arabic', 'الوحدة ٧ · الأدب العربي في الهند', 'medium');
INSERT OR IGNORE INTO quizzes (id, title, description, instructions, subject, topic, difficulty, status, mode, duration_minutes, attempt_limit, pass_mark, marks_per_question, negative_marks, shuffle_questions, shuffle_options, show_answers, access_type, published_at) VALUES (1013, 'الوحدة ٧ — اختيار من متعدد', 'الأدب العربي في الهند', 'اقرأ كل سؤال بعناية ثم اختر إجابة واحدة صحيحة. لكل سؤال درجتان ولا خصم على الإجابة الخاطئة.', 'UGC NET Arabic', 'الأدب العربي في الهند', 'medium', 'published', 'both', 15, 0, 40, 2, 0, 0, 0, 1, 'free', datetime('now'));
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1013, 100193, 0);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1013, 100194, 1);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1013, 100195, 2);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1013, 100196, 3);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1013, 100197, 4);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1013, 100198, 5);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1013, 100199, 6);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1013, 100200, 7);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1013, 100201, 8);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1013, 100202, 9);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1013, 100203, 10);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1013, 100204, 11);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1013, 100205, 12);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1013, 100206, 13);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1013, 100207, 14);

INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100208, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - شاه ولي الله الدهلوي حنفي أشعري العقيدة
2 - من كتبه «التفهيمات الإلهية»
3 - توفي شاه ولي الله في إندونيسيا', '["العبارات 1 و 2 و 3 جميعها صحيحة", "العبارة 1 فقط صحيحة", "العبارتان 1 و 2 فقط صحيحتان", "العبارة 3 فقط صحيحة"]', '[2]', 'توفي في الهند.', 'UGC NET Arabic', 'الوحدة ٧ · الأدب العربي في الهند', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100209, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - وُلد صديق حسن خان في القاهرة
2 - تزوج ملكة بهوبال ونال لقب نواب
3 - من كتبه «السراج الوهاج»', '["العبارة 2 فقط صحيحة", "العبارتان 2 و 3 فقط صحيحتان", "العبارتان 1 و 3 فقط صحيحتان", "العبارة 1 فقط صحيحة"]', '[1]', 'وُلد في بانس بريلي بالهند.', 'UGC NET Arabic', 'الوحدة ٧ · الأدب العربي في الهند', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100210, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - لُقّب عبد الحي الحسني بابن خلكان الهند
2 - كان ذلك لكتابه في الشعر الجاهلي
3 - كتابه في تراجم العلماء', '["العبارات 1 و 2 و 3 جميعها صحيحة", "العبارتان 1 و 3 فقط صحيحتان", "العبارتان 1 و 2 فقط صحيحتان", "العبارة 1 فقط صحيحة"]', '[1]', 'اللقب بسبب كتابه في تراجم العلماء؛ فالعبارة 2 خاطئة.', 'UGC NET Arabic', 'الوحدة ٧ · الأدب العربي في الهند', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100211, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - وُلد عبد العزيز الميمني في راجكوت
2 - توفي في كراتشي
3 - حقق «الوحشيات» الحماسة الصغرى لأبي تمام', '["العبارتان 1 و 3 فقط صحيحتان", "العبارة 2 فقط صحيحة", "العبارات 1 و 2 و 3 جميعها صحيحة", "العبارة 3 فقط صحيحة"]', '[2]', 'العبارات الثلاث صحيحة.', 'UGC NET Arabic', 'الوحدة ٧ · الأدب العربي في الهند', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100212, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - ألّف الفراهي «فيض الباري»
2 - أول كتاب للندوي «سيرة السيد أحمد شهيد» بالعربية
3 - كتب الندوي افتتاحيات مجلة «المسلمون» الدمشقية', '["العبارتان 2 و 3 فقط صحيحتان", "العبارة 3 فقط صحيحة", "العبارتان 1 و 3 فقط صحيحتان", "العبارة 2 فقط صحيحة"]', '[1]', '«فيض الباري» للكشميري، وأول كتاب للندوي بالأردية؛ فالعبارة 3 فقط صحيحة.', 'UGC NET Arabic', 'الوحدة ٧ · الأدب العربي في الهند', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100213, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - اشتغل أبو الحسن الندوي بالدعوة مع جماعة التبليغ
2 - وُلد في قرية تكية بمديرية راي بريلي
3 - وُلد أبو الحسن الندوي في دلهي', '["العبارتان 1 و 3 فقط صحيحتان", "العبارتان 1 و 2 فقط صحيحتان", "العبارات 1 و 2 و 3 جميعها صحيحة", "العبارة 3 فقط صحيحة"]', '[1]', 'ولد في تكية براي بريلي.', 'UGC NET Arabic', 'الوحدة ٧ · الأدب العربي في الهند', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100214, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - حفظ أنور شاه الكشميري القرآن في أربعة أشهر
2 - «فيض الباري» شرح لصحيح البخاري
3 - «فصل الخطاب في مسألة أم الكتاب» من كتب الكشميري', '["العبارتان 1 و 2 فقط صحيحتان", "العبارتان 2 و 3 فقط صحيحتان", "العبارة 2 فقط صحيحة", "العبارة 3 فقط صحيحة"]', '[1]', 'الذي حفظ القرآن في أربعة أشهر هو فضل الحق الخيرآبادي؛ فالعبارة 1 خاطئة.', 'UGC NET Arabic', 'الوحدة ٧ · الأدب العربي في الهند', 'medium');
INSERT OR IGNORE INTO questions (id, type, text, options_json, correct_json, explanation, subject, topic, difficulty) VALUES (100215, 'mcq', 'اقرأ العبارات الآتية، ثم اختر الإجابة الصحيحة:
1 - نُفي فضل الحق الخيرآبادي إلى جزيرة أندمان
2 - توفي فضل الحق في دلهي
3 - ألّف فضل الحق «فيض الباري»', '["العبارتان 2 و 3 فقط صحيحتان", "العبارة 3 فقط صحيحة", "العبارة 2 فقط صحيحة", "العبارة 1 فقط صحيحة"]', '[3]', 'توفي في أندمان، و«فيض الباري» للكشميري.', 'UGC NET Arabic', 'الوحدة ٧ · الأدب العربي في الهند', 'medium');
INSERT OR IGNORE INTO quizzes (id, title, description, instructions, subject, topic, difficulty, status, mode, duration_minutes, attempt_limit, pass_mark, marks_per_question, negative_marks, shuffle_questions, shuffle_options, show_answers, access_type, published_at) VALUES (1014, 'الوحدة ٧ — أسئلة العبارات', 'الأدب العربي في الهند', 'اقرأ العبارات في كل سؤال، ثم اختر الخيار الذي يحدد العبارات الصحيحة. لكل سؤال درجتان ولا خصم على الإجابة الخاطئة.', 'UGC NET Arabic', 'الأدب العربي في الهند', 'medium', 'published', 'both', 12, 0, 40, 2, 0, 0, 0, 1, 'free', datetime('now'));
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1014, 100208, 0);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1014, 100209, 1);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1014, 100210, 2);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1014, 100211, 3);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1014, 100212, 4);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1014, 100213, 5);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1014, 100214, 6);
INSERT OR IGNORE INTO quiz_questions (quiz_id, question_id, position) VALUES (1014, 100215, 7);
