# Arabic question bank (7 units)

215 questions (145 multiple choice, 70 statement type) written from the course notes `naseer_pdf.pdf`.

Each `unit-N.json` has `mcq` and `st` lists. Fields: `x` question, `st` statements (statement type only), `o` four options, `c` index of the correct option (0-based), `e` explanation, `d` difficulty.

The phone apps already contain these as published quizzes. For the server project, load them through the creator's JSON import after mapping the fields (`x`→question text, `o`→options, `c`→correct index).
